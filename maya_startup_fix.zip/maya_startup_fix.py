"""
Maya 启动修复工具 — 一键解决场景打开后常见问题。

修复内容：
  1. 解锁 defaultTextureList1.textures —— 解决 "Connection not made: Destination is locked"
  2. 清理 filePathEditor 重复注册警告
  3. 修复 file 节点的 colorSpace 设置（OCIO 配置中缺失 sRGB 时回退为安全值）
  4. 报告 XGen 缺失文件和贴图路径问题（不自动修复，仅列出）

使用方法：
  方法A — Maya Script Editor (Python 标签页) 中粘贴运行：
    exec(open(r'D:\\zcy\\ai_ty\\maya_startup_fix.py', encoding='utf-8').read())

  方法B — 要每次打开 Maya 自动运行，在 userSetup.py 中加入：
    import sys; sys.path.append(r'D:\zcy\ai_ty')
    import maya_startup_fix; maya_startup_fix.run()

  方法C — 单独调用某个功能：
    import maya_startup_fix
    maya_startup_fix.unlock_default_texture_list()
    maya_startup_fix.clean_filepath_editor_registry()
    maya_startup_fix.fix_file_colorspaces()
    maya_startup_fix.report_missing_paths()
"""

import maya.cmds as cmds
import sys
import os


# ============================================================================
# 1. 解锁 defaultTextureList1.textures
# ============================================================================

def unlock_default_texture_list():
    """
    解锁 defaultTextureList1.textures 属性。

    问题现象：创建 file 节点时报错：
        Error: Connection not made: 'fileXXX.message' -> 'defaultTextureList1.textures[-1]'.
        Destination is locked.

    原因：defaultTextureList1 是 Maya 内部管理所有 file 纹理节点的列表，
         节点本身作为 container 被锁定，导致其子属性也被锁。
         必须先解锁节点，再解锁属性。

    解决策略（按优先级尝试）：
      1. lockNode -lock 0 解锁节点容器
      2. setAttr 解锁 textures 属性
      3. 用 MEL 命令强制解锁
    """
    node_name = "defaultTextureList1"
    attr_name = "textures"

    if not cmds.objExists(node_name):
        print("[fix_startup] {} 节点不存在，跳过。".format(node_name))
        return False

    # 先检查属性是否已经被锁
    try:
        locked = cmds.getAttr(node_name + "." + attr_name, lock=True)
    except Exception:
        locked = True  # 读不到就假定锁定

    if not locked:
        print("[fix_startup] {} 已经是解锁状态，无需修复。".format(node_name + "." + attr_name))
        return True

    # 策略1：解锁节点本身（container lock）
    try:
        cmds.lockNode(node_name, lock=False, lockUnpublished=False)
        print("[fix_startup]   已解锁节点 {}".format(node_name))
    except Exception as e1:
        print("[fix_startup]   解锁节点失败 ({}), 尝试其他方式...".format(e1))

    # 策略2：解锁属性
    try:
        cmds.setAttr(node_name + "." + attr_name, lock=False)
        print("[fix_startup] ✓ 已解锁 {}".format(node_name + "." + attr_name))
        return True
    except Exception as e2:
        pass  # 继续尝试

    # 策略3：通过 MEL 强制解锁
    try:
        import maya.mel as mel
        mel.eval('setAttr -lock 0 {}.{};'.format(node_name, attr_name))
        print("[fix_startup] ✓ 通过 MEL 已解锁 {}".format(node_name + "." + attr_name))
        return True
    except Exception as e3:
        pass

    # 策略4：删除并让 Maya 重新创建该节点
    # 注意：这是最后手段，可能影响场景中的 file 节点连接
    try:
        cmds.lockNode(node_name, lock=False, lockUnpublished=False)
        cmds.delete(node_name)
        print("[fix_startup]   已删除 {}, Maya 将自动重建".format(node_name))
        # Maya 在下次创建 file 节点时会自动重建 defaultTextureList1
        return True
    except Exception as e4:
        print("[fix_startup] ✗ 所有方法均失败: {}".format(e4))
        return False


# ============================================================================
# 2. 清理 filePathEditor 重复注册警告
# ============================================================================

def clean_filepath_editor_registry():
    """
    清理 filePathEditor 中的重复属性注册。

    问题现象：
        Warning: filePathEditor: Attribute 'aiImage.filename' is invalid or
        is not designated 'usedAsFilename'.   (Arnold 未加载时属性不存在)
        Warning: filePathEditor: Attribute 'aiStandIn.dso' and label 'Standin'
        have been saved already.              (重复注册)

    原因：prefs 文件 filePathEditorRegistryPrefs.mel 中记录了 Arnold 属性，
         但每次 Maya 启动、Arnold 加载时又写入一次，导致重复。
         如果 Arnold 加载晚于 prefs 读取，还会报 "invalid attribute"。

    解决：
      1. 删除硬盘上的 filePathEditorRegistryPrefs.mel，重启 Maya 后 Arnold 会写一份干净的
      2. 同时清理内存中的 optionVar
    """
    cleaned = False

    # --- 方法1：直接删除 prefs 文件（最彻底） ---
    maya_version = cmds.about(version=True)
    prefs_dir = os.path.join(
        os.path.expanduser("~"), "Documents", "maya", maya_version, "prefs"
    )
    prefs_file = os.path.join(prefs_dir, "filePathEditorRegistryPrefs.mel")

    if os.path.exists(prefs_file):
        try:
            backup = prefs_file + ".bak"
            # 先备份
            with open(prefs_file, 'r') as f:
                content = f.read()
            # 只保留非 Arnold 的行（安全做法：清空全部，让插件重建）
            # 实际上直接删掉最干净，Maya 和插件会自动重建
            os.remove(prefs_file)
            print("[fix_startup] ✓ 已删除 {}".format(prefs_file))
            print("[fix_startup]   下次启动 Maya 时插件会重新生成干净的注册。")
            cleaned = True
        except Exception as e:
            print("[fix_startup] ⚠ 无法删除 prefs 文件: {}".format(e))

    # --- 方法2：清理内存中的 optionVar ---
    # Maya 中 filePathEditor 的注册可能也缓存在 optionVar 里
    try:
        all_vars = cmds.optionVar(list=True) or []
    except Exception:
        all_vars = []

    # 尝试多种前缀（不同 Maya 版本可能不同）
    prefixes = [
        "filePathEditorRegistry",
        "filePathEditor",
        "fpeRegistry",
    ]
    removed = 0
    for var in all_vars:
        for prefix in prefixes:
            if var.lower().startswith(prefix.lower()):
                try:
                    cmds.optionVar(remove=var)
                    removed += 1
                except Exception:
                    pass
                break

    if removed > 0:
        print("[fix_startup] ✓ 已清理 {} 个 filePathEditor optionVar。".format(removed))
        cleaned = True

    if not cleaned:
        print("[fix_startup] 未找到需要清理的 filePathEditor 注册。")

    return cleaned


# ============================================================================
# 3. 修复 file 节点 colorSpace
# ============================================================================

def get_available_color_spaces():
    """获取当前 OCIO 配置中所有可用的色彩空间名称列表"""
    try:
        return cmds.colorManagementPrefs(query=True, colorSpaceNames=True) or []
    except Exception:
        return []


def get_input_color_spaces():
    """获取输入色彩空间列表（用于 file 节点）"""
    try:
        return cmds.colorManagementPrefs(query=True, inputSpaceNames=True) or []
    except Exception:
        return []


def fix_file_colorspaces(dry_run=False):
    """
    修复所有 file 节点的 .colorSpace 属性。

    问题现象：
        Warning: Color space "sRGB" in node ":file65" is not defined
        in the selected transform collection.

    原因：Maya 场景引用了一个在当前 OCIO 配置中不存在的色彩空间。
         通常是场景在另一台机器/配置下创建的。

    修复逻辑：
      1. 读取当前可用的色彩空间列表
      2. 扫描全部 file 节点
      3. 如果 file 节点的 colorSpace 不在可用列表中：
         - 尝试映射到等效空间（如 "sRGB" -> "SRGB", "Raw" -> "ACES - ACEScg"）
         - 如果找不到映射，设为 "Raw" 或列表中的第一个空间
      4. 也可以关闭色彩管理（将 colorSpace 置空）

    参数:
        dry_run: True 则只报告不修改
    """
    available = set(get_available_color_spaces())
    input_spaces = set(get_input_color_spaces()) if get_input_color_spaces() else available

    if not available:
        print("[fix_startup] ⚠ 未检测到任何色彩空间，可能是 OCIO 配置缺失。")
        print("[fix_startup]   跳过修复，不修改任何色彩管理设置。")
        return 0, 0

    # 常用色彩空间名映射（不区分大小写）
    # OCIO 配置版本不同可能导致同一个空间名写法不同
    FALLBACK_MAP = {
        "sRGB":       ["sRGB", "srgb", "sRGB - Display", "sRGB Texture", "SRGB", "Utility - sRGB - Texture"],
        "Raw":        ["Raw", "raw", "RAW", "Utility - Raw", "ACES - ACEScg", "ACEScg"],
        "Linear":     ["Linear", "linear", "scene_linear", "ACES - ACEScg"],
        "ACEScg":     ["ACEScg", "ACES - ACEScg", "acescg"],
        "ACES2065-1": ["ACES2065-1", "ACES - ACES2065-1"],
        "input":      [],
    }

    file_nodes = cmds.ls(type="file")
    if not file_nodes:
        print("[fix_startup] 场景中没有 file 节点。")
        return 0, 0

    fixed = 0
    reported = 0

    for fn in file_nodes:
        # 检查是否有 colorSpace 属性（老版本 Maya 没有）
        if not cmds.attributeQuery("colorSpace", node=fn, exists=True):
            continue

        try:
            current_cs = cmds.getAttr(fn + ".colorSpace")
        except Exception:
            continue

        if not current_cs:
            continue  # 空值 = 无色彩管理，正常

        if current_cs in available:
            continue  # 已正常

        reported += 1

        # 尝试找到等效空间
        candidates = FALLBACK_MAP.get(current_cs, [current_cs])
        replacement = None

        for cand in candidates:
            # 精确匹配
            if cand in available:
                replacement = cand
                break
            # 不区分大小写匹配
            lower_match = [s for s in available if s.lower() == cand.lower()]
            if lower_match:
                replacement = lower_match[0]
                break
            # 子串匹配
            sub_matches = [s for s in available if cand.lower() in s.lower()]
            if sub_matches:
                replacement = sub_matches[0]
                break

        # 如果所有尝试都失败，看 input_spaces 里有什么
        if replacement is None and input_spaces:
            # 从 input_spaces 中选一个最通用的
            for pref in ["Raw", "Utility - Raw", "ACES - ACEScg"]:
                if pref in input_spaces:
                    replacement = pref
                    break
            if replacement is None:
                replacement = sorted(input_spaces)[0]

        if replacement is None:
            # 无法映射：跳过，不修改（保持原样，由用户手动处理）
            print("[fix_startup] ⚠ {}: colorSpace='{}' 无法映射到可用空间，跳过".format(fn, current_cs))
            continue

        if dry_run:
            print("[fix_startup] [DRY RUN] {}: '{}' -> '{}'".format(fn, current_cs, replacement))
        else:
            try:
                cmds.setAttr(fn + ".colorSpace", replacement, type="string")
                fixed += 1
                print("[fix_startup] ✓ {}: '{}' -> '{}'".format(fn, current_cs, replacement))
            except Exception as e:
                print("[fix_startup] ✗ {}: 设置失败 -- {}".format(fn, e))

    if dry_run:
        print("[fix_startup] [DRY RUN] 共发现 {} 个 file 节点 colorSpace 有问题。".format(reported))
    else:
        print("[fix_startup] ✓ 共修复 {} / {} 个 file 节点 colorSpace。".format(fixed, reported))

    return fixed, reported


# ============================================================================
# 4. 报告缺失路径（XGen / 贴图）
# ============================================================================

def report_missing_paths():
    """
    扫描场景中所有指向不存在路径的节点，汇总报告。

    不自动修复（因为需要找到实际文件），只列出清单方便排查。

    检查范围：
      - file 节点的 .fileTextureName
      - XGen 相关路径（从 errors 中抓取）
      - aiImage, aiStandIn 等 Arnold 节点
    """
    print("-" * 50)
    print("  缺失文件/路径扫描")
    print("-" * 50)

    missing = []

    # 检查 file 节点
    file_nodes = cmds.ls(type="file")
    for fn in file_nodes:
        try:
            tex_path = cmds.getAttr(fn + ".fileTextureName")
        except Exception:
            continue
        if tex_path and not os.path.exists(tex_path):
            missing.append(("file", fn, tex_path))

    # 检查 aiImage 节点
    for node_type in ["aiImage", "aiStandIn", "aiVolume"]:
        nodes = cmds.ls(type=node_type)
        for n in nodes:
            attr_map = {
                "aiImage":   "filename",
                "aiStandIn": "dso",
                "aiVolume":  "filename",
            }
            attr = attr_map.get(node_type, "filename")
            try:
                p = cmds.getAttr(n + "." + attr)
            except Exception:
                continue
            if p and not os.path.exists(p):
                # 展开环境变量
                expanded = os.path.expandvars(p)
                if not os.path.exists(expanded):
                    missing.append((node_type, n, p))

    if not missing:
        print("  ✓ 所有引用的文件路径都存在。")
        return missing

    print("  共 {} 个文件/路径不存在：\n".format(len(missing)))

    # 按类型分组输出
    from collections import defaultdict
    grouped = defaultdict(list)
    for typ, node, path in missing:
        grouped[typ].append((node, path))

    for typ, items in sorted(grouped.items()):
        print("  [{}] {} 个节点：".format(typ, len(items)))
        for node, path in items:
            # 截断路径以保持可读
            display_path = path if len(path) < 120 else "..." + path[-117:]
            print("    {} -> {}".format(node, display_path))

    print("")
    print("  提示：这些文件通常需要从发布目录或源电脑拷贝。")
    print("        如果是 XGen 文件 (.xpd/.ptx)，需要将整个 xgen 目录")
    print("        放到项目路径下，或在 XGen 编辑器中重新设置路径。")

    return missing


# ============================================================================
# 5. 一键运行
# ============================================================================

def run(dry_run=False):
    """
    一键执行所有修复。

    参数:
        dry_run: True 则只检查不修改（仅 colorSpace 修复受此参数影响）
    """
    print("=" * 60)
    print("  Maya 启动修复工具 — maya_startup_fix")
    print("=" * 60)
    print("")

    # 1. 解锁 defaultTextureList1
    print("[1/4] 解锁 defaultTextureList1.textures ...")
    unlock_default_texture_list()
    print("")

    # 2. 清理 filePathEditor 注册（删除 prefs 文件 + 清 optionVar）
    print("[2/4] 清理 filePathEditor 重复注册 ...")
    clean_filepath_editor_registry()
    print("")

    # 3. 修复 file 节点 colorSpace
    print("[3/4] 修复 file 节点 colorSpace ...")
    fix_file_colorspaces(dry_run=dry_run)
    print("")

    # 4. 报告缺失路径
    print("[4/4] 扫描缺失路径 ...")
    report_missing_paths()
    print("")

    print("=" * 60)
    print("  修复完成。")
    if dry_run:
        print("  (dry-run 模式，未实际修改任何数据)")
    print("=" * 60)


# ============================================================================
# 入口
# ============================================================================

if __name__ == "__main__" or __name__ == "__builtin__":
    run()
