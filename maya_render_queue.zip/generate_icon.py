"""
纯 Python 生成 ICO 图标 — 透明底 + 黄色粗体 M
不依赖任何第三方库
"""
import struct
import math

SIZE = 64
FG = (255, 215, 0, 255)   # 黄色 M（不透明）
BG = (0, 0, 0, 0)    # 透明

def draw_m(pixels, size, color):
    """在像素 grid 上绘制一个粗体 M 字母"""
    cx, cy = size // 2, size // 2
    hw = size * 0.18      # 半宽
    stroke = max(2, int(size * 0.19))
    top_y = int(size * 0.12)
    bot_y = int(size * 0.88)

    def paint(x, y):
        if 0 <= x < size and 0 <= y < size:
            pixels[y][x] = color

    # M: 四条斜线 + 两条竖线结构
    # 左竖线
    left_x = int(size * 0.15)
    right_x = int(size * 0.85)
    mid_x = size // 2

    for dx in range(-stroke//2, stroke//2 + 1):
        for y in range(top_y, bot_y + 1):
            # 左竖
            paint(left_x + dx, y)
            # 右竖
            paint(right_x + dx, y)
            # 左斜 (left_x → mid_x)
            t = (y - top_y) / (bot_y - top_y)
            mx = int(left_x + t * (mid_x - left_x))
            paint(mx + dx, y)
            # 右斜 (mid_x → right_x)
            mx2 = int(mid_x + (1 - t) * (right_x - mid_x))
            paint(mx2 + dx, y)

    # 顶部横连
    for y in range(top_y - stroke//2, top_y + stroke//2 + 1):
        for x in range(left_x - stroke//2, right_x + stroke//2 + 1):
            if 0 <= x < size and 0 <= y < size:
                # 只在 V 形尖端附近
                pass


def draw_m_v2(pixels, size, color):
    """更可靠的 M 绘制 — 用线段方程"""
    stroke = max(3, int(size * 0.17))
    margin = int(size * 0.12)
    left_x = margin
    right_x = size - margin
    bot_y = size - margin
    top_y = margin

    def thick_line(x1, y1, x2, y2, w):
        """Bresenham 粗线"""
        for dx in range(-w//2, w//2 + 1):
            for dy in range(-w//2, w//2 + 1):
                _draw_line(pixels, size, x1+dx, y1+dy, x2+dx, y2+dy, color)

    def _draw_line(pixels, size, x1, y1, x2, y2, color):
        dx = abs(x2 - x1)
        dy = -abs(y2 - y1)
        sx = 1 if x1 < x2 else -1
        sy = 1 if y1 < y2 else -1
        err = dx + dy
        while True:
            if 0 <= x1 < size and 0 <= y1 < size:
                pixels[y1][x1] = color
            if x1 == x2 and y1 == y2:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x1 += sx
            if e2 <= dx:
                err += dx
                y1 += sy

    mid_x = size // 2
    # 左竖线
    thick_line(left_x, top_y, left_x, bot_y, stroke)
    # 右竖线
    thick_line(right_x, top_y, right_x, bot_y, stroke)
    # 左斜: 左上 → 中下 → 右上  (实际上 M 是 left→mid, mid→right)
    # M 形状: left_top → mid_bot → right_top
    #   |\  /|
    #   | \/ |
    #   | /\ |
    #   |/  \|
    # Left→Mid slant (left_top → mid_bot):
    thick_line(left_x + stroke//2, top_y, mid_x, bot_y - stroke//2, stroke)
    # Mid→Right slant (mid_bot → right_top):
    thick_line(mid_x, bot_y - stroke//2, right_x - stroke//2, top_y, stroke)
    # Left→Mid reverse (left_bot → mid_top):
    thick_line(left_x + stroke//2, bot_y, mid_x, top_y + stroke//2, stroke)
    # Mid→Right reverse (mid_top → right_bot):
    thick_line(mid_x, top_y + stroke//2, right_x - stroke//2, bot_y, stroke)


def make_ico(size=64, sizes=[32, 48, 64]):
    """生成多分辨率 ICO 文件"""
    images = []

    for s in sizes:
        # 创建 RGBA 像素数据
        pixels = [[(0, 0, 0, 0) for _ in range(s)] for _ in range(s)]
        draw_m_v2(pixels, s, FG)

        # 转为 BMP 格式（ICO 内嵌 BMP）
        bmp_data = pixels_to_bmp(pixels, s)
        images.append((s, bmp_data))

    # 构建 ICO
    return build_ico(images)


def pixels_to_bmp(pixels, size):
    """将 RGBA 像素转为 32-bit BMP（含 alpha 通道）"""
    # BITMAPINFOHEADER
    hdr_size = 40
    width = size
    height = size * 2  # XOR mask + AND mask
    planes = 1
    bpp = 32
    compression = 0
    row_size = width * 4
    img_size = row_size * height
    data_offset = hdr_size

    header = struct.pack('<IiiHHIIiiII',
        hdr_size, width, height, planes, bpp,
        compression, img_size, 0, 0, 0, 0)

    # XOR mask (bottom-up)
    xor_rows = []
    for y in range(size - 1, -1, -1):
        row = bytearray()
        for x in range(size):
            r, g, b, a = pixels[y][x]
            # BGRA
            row.extend([b, g, r, a])
        xor_rows.append(bytes(row))

    # AND mask (1-bit, bottom-up)
    and_row_size = ((width + 31) // 32) * 4
    and_rows = []
    for y in range(size - 1, -1, -1):
        row = bytearray(and_row_size)
        for x in range(width):
            a = pixels[y][x][3]
            if a < 128:  # 透明 → AND mask bit = 1
                byte_idx = x // 8
                bit_idx = 7 - (x % 8)
                row[byte_idx] |= (1 << bit_idx)
        and_rows.append(bytes(row))

    return header + b''.join(xor_rows) + b''.join(and_rows)


def build_ico(images):
    """构建 ICO 文件"""
    num = len(images)
    # 文件头
    header = struct.pack('<HHH', 0, 1, num)

    # 计算偏移
    entry_size = 16
    data_offset = 6 + num * entry_size

    entries = b''
    data_chunks = b''

    for s, bmp in images:
        bmp_size = len(bmp)
        # ICO 条目: width, height, colors, reserved, planes, bpp, size, offset
        # width/height: 0 means 256
        w = s if s < 256 else 0
        h = s if s < 256 else 0
        entry = struct.pack('<BBBBHHII',
            w, h, 0, 0, 1, 32, bmp_size, data_offset)
        entries += entry
        data_offset += bmp_size
        data_chunks += bmp

    return header + entries + data_chunks


if __name__ == '__main__':
    import os

    ico_data = make_ico(64, sizes=[32, 48, 64])
    out_path = os.path.join(os.path.dirname(__file__), 'icon.ico')
    with open(out_path, 'wb') as f:
        f.write(ico_data)

    print(f"Icon saved: {out_path} ({len(ico_data)} bytes)")
