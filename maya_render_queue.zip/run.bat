@echo off
cd /d "%~dp0"

set "MAYA_PY="

rem Auto-detect installed Maya versions (highest first)
for /d %%v in ("C:\Program Files\Autodesk\Maya*") do (
    if exist "%%v\bin\mayapy.exe" (
        if "%MAYA_PY%"=="" set "MAYA_PY=%%v\bin\mayapy.exe"
    )
)

if "%MAYA_PY%"=="" (
    echo Error: Maya not found in default path
    echo Please check C:\Program Files\Autodesk\
    pause
    exit /b 1
)

"%MAYA_PY%" main.py
if errorlevel 1 (
    echo.
    echo Error: failed to start. Check that Maya is installed.
    echo Log files are in the "logs" folder.
)
pause
