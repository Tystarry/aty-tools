@echo off
cd /d "%~dp0"

set "MAYA_PY="

rem 自动查找已安装的 Maya 版本（从高到低）
for /d %%v in ("C:\Program Files\Autodesk\Maya*") do (
    if exist "%%v\bin\mayapy.exe" (
        if "%MAYA_PY%"=="" set "MAYA_PY=%%v\bin\mayapy.exe"
    )
)

if "%MAYA_PY%"=="" (
    echo Error: 未检测到已安装的 Maya
    echo 请确认 Maya 安装在默认路径 C:\Program Files\Autodesk\
    pause
    exit /b 1
)

"%MAYA_PY%" main.py
pause
