@echo off
cd /d "%~dp0"

set "MAYA_PY="
if exist "C:\Program Files\Autodesk\Maya2024\bin\mayapy.exe" (
    set "MAYA_PY=C:\Program Files\Autodesk\Maya2024\bin\mayapy.exe"
) else if exist "C:\Program Files\Autodesk\Maya2022\bin\mayapy.exe" (
    set "MAYA_PY=C:\Program Files\Autodesk\Maya2022\bin\mayapy.exe"
)

if "%MAYA_PY%"=="" (
    echo Error: Maya not found
    pause
    exit /b 1
)

"%MAYA_PY%" main.py
pause
