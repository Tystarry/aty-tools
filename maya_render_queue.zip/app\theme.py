"""
Qt 深色主题 — PySide2 stylesheet
"""
QT_STYLESHEET = """
/* ── 全局 ── */
QWidget {
    background-color: #1e1e2e;
    color: #e0e0e0;
    font-family: "Segoe UI", "Microsoft YaHei", sans-serif;
    font-size: 13px;
}

QMainWindow {
    background-color: #1e1e2e;
}

/* ── 按钮 ── */
QPushButton {
    background-color: #33334d;
    color: #e0e0e0;
    border: 1px solid #3e3e55;
    border-radius: 4px;
    padding: 5px 14px;
    min-height: 24px;
}
QPushButton:hover {
    background-color: #3e3e5a;
    border-color: #5a5a7a;
}
QPushButton:pressed {
    background-color: #2a2a40;
}
QPushButton:disabled {
    background-color: #252535;
    color: #666;
}

QPushButton#startBtn {
    background-color: #4a9a4a;
    color: #fff;
    font-weight: bold;
    padding: 6px 22px;
    border: none;
}
QPushButton#startBtn:hover {
    background-color: #5ab85a;
}
QPushButton#startBtn:pressed {
    background-color: #3d8a3d;
}
QPushButton#startBtn:disabled {
    background-color: #2a4a2a;
    color: #556655;
}

QPushButton#stopBtn {
    background-color: #c04040;
    color: #fff;
    font-weight: bold;
    padding: 6px 22px;
    border: none;
}
QPushButton#stopBtn:hover {
    background-color: #d45050;
}
QPushButton#stopBtn:pressed {
    background-color: #a03030;
}
QPushButton#stopBtn:disabled {
    background-color: #4a2a2a;
    color: #554444;
}

/* ── 输入框 ── */
QLineEdit, QSpinBox, QDoubleSpinBox {
    background-color: #28283a;
    color: #e0e0e0;
    border: 1px solid #3e3e55;
    border-radius: 3px;
    padding: 4px 8px;
    min-height: 22px;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {
    border-color: #5a9ec9;
}

/* ── 下拉框 ── */
QComboBox {
    background-color: #28283a;
    color: #e0e0e0;
    border: 1px solid #3e3e55;
    border-radius: 3px;
    padding: 4px 8px;
    min-height: 22px;
}
QComboBox:hover {
    border-color: #5a5a7a;
}
QComboBox::drop-down {
    border: none;
    width: 20px;
}
QComboBox QAbstractItemView {
    background-color: #28283a;
    color: #e0e0e0;
    border: 1px solid #3e3e55;
    selection-background-color: #5a9ec9;
    selection-color: #fff;
    outline: none;
}

/* ── 树形列表 ── */
QTreeWidget {
    background-color: #28283a;
    color: #e0e0e0;
    border: 1px solid #3e3e55;
    border-radius: 4px;
    outline: none;
    alternate-background-color: #2c2c40;
}
QTreeWidget::item {
    padding: 4px 6px;
    min-height: 26px;
}
QTreeWidget::item:selected {
    background-color: #5a9ec9;
    color: #fff;
}
QTreeWidget::item:hover:!selected {
    background-color: #33334d;
}
QHeaderView::section {
    background-color: #1e1e2e;
    color: #a0a0b0;
    border: none;
    border-bottom: 2px solid #3e3e55;
    padding: 6px 8px;
    font-weight: bold;
}

/* ── 分组框 ── */
QGroupBox {
    border: 1px solid #3e3e55;
    border-radius: 4px;
    margin-top: 10px;
    padding-top: 12px;
    font-weight: bold;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 6px;
    color: #a0a0b0;
}

/* ── 日志 ── */
QPlainTextEdit {
    background-color: #1a1a2a;
    color: #c0c0d0;
    border: 1px solid #3e3e55;
    border-radius: 3px;
    font-family: "Consolas", "Courier New", monospace;
    font-size: 12px;
}

/* ── 滚动条 ── */
QScrollBar:vertical {
    background-color: #1e1e2e;
    width: 10px;
    border: none;
}
QScrollBar::handle:vertical {
    background-color: #44445a;
    border-radius: 5px;
    min-height: 30px;
    margin: 2px;
}
QScrollBar::handle:vertical:hover {
    background-color: #555570;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar:horizontal {
    background-color: #1e1e2e;
    height: 10px;
}
QScrollBar::handle:horizontal {
    background-color: #44445a;
    border-radius: 5px;
    min-width: 30px;
    margin: 2px;
}

/* ── 对话框 ── */
QDialog {
    background-color: #1e1e2e;
}

/* ── 标签 ── */
QLabel {
    background: transparent;
    color: #c0c0d0;
}

/* ── 垂直分隔线 ── */
QFrame[frameShape="5"] {  /* VLine */
    background-color: #3e3e55;
    max-width: 1px;
}

/* ── 提示框 ── */
QMessageBox {
    background-color: #1e1e2e;
}
QMessageBox QLabel {
    color: #e0e0e0;
}
"""
