"""
队列管理器 — 增删改查 + JSON 文件持久化
"""
import os
from .job_model import RenderJob, jobs_to_json, jobs_from_json


class QueueManager:
    """管理渲染队列的数据层"""

    def __init__(self, save_path=None):
        if save_path is None:
            save_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "jobs.json")
        self._save_path = save_path
        self._jobs = []
        self._on_change = None

    def set_on_change(self, callback):
        self._on_change = callback

    def _notify(self):
        if self._on_change:
            self._on_change()
        self.save()

    # ── 增删改查 ──

    def add(self, job: RenderJob):
        self._jobs.append(job)
        self._notify()

    def remove(self, job_id: str):
        self._jobs = [j for j in self._jobs if j.id != job_id]
        self._notify()

    def remove_many(self, job_ids: list):
        ids_set = set(job_ids)
        self._jobs = [j for j in self._jobs if j.id not in ids_set]
        self._notify()

    def get(self, job_id: str):
        for j in self._jobs:
            if j.id == job_id:
                return j
        return None

    def update(self, job_id: str, **kwargs):
        job = self.get(job_id)
        if job:
            for k, v in kwargs.items():
                if hasattr(job, k):
                    setattr(job, k, v)
            self._notify()

    def move_up(self, job_id: str):
        for i, j in enumerate(self._jobs):
            if j.id == job_id and i > 0:
                self._jobs[i], self._jobs[i - 1] = self._jobs[i - 1], self._jobs[i]
                self._notify()
                return

    def move_down(self, job_id: str):
        for i, j in enumerate(self._jobs):
            if j.id == job_id and i < len(self._jobs) - 1:
                self._jobs[i], self._jobs[i + 1] = self._jobs[i + 1], self._jobs[i]
                self._notify()
                return

    @property
    def all(self):
        return list(self._jobs)

    @property
    def pending(self):
        return [j for j in self._jobs if j.status == "pending"]

    @property
    def count(self):
        return len(self._jobs)

    def set_status(self, job_id: str, status: str, error_msg: str = ""):
        job = self.get(job_id)
        if job:
            job.status = status
            job._error_msg = error_msg
            self._notify()

    # ── 持久化 ──

    def save(self):
        try:
            os.makedirs(os.path.dirname(self._save_path), exist_ok=True)
            with open(self._save_path, "w", encoding="utf-8") as f:
                f.write(jobs_to_json(self._jobs))
        except Exception as e:
            print(f"[QueueManager] save error: {e}")

    def load(self):
        if not os.path.isfile(self._save_path):
            return
        try:
            with open(self._save_path, "r", encoding="utf-8") as f:
                text = f.read()
            if text.strip():
                self._jobs = jobs_from_json(text)
                for j in self._jobs:
                    if j.status == "running":
                        j.status = "pending"
        except Exception as e:
            print(f"[QueueManager] load error: {e}")
            self._jobs = []
        self._notify()
