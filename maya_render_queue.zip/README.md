# Maya Render Queue

独立桌面渲染队列管理器 — 批量配置多个 Maya 场景文件，通过 Maya 内置的 Render Sequence 依次渲染。

支持 Arnold / Redshift，自动设置帧范围、分辨率、采样、输出路径、渲染层。

---

## 环境要求

- Windows 10/11
- Maya 2022+ 已安装（自动检测，支持多版本）
- 无需额外安装 Python 依赖

---

## 启动方式

双击桌面快捷方式 `M_R`，或直接运行 `run.bat`。

第一次使用需要先在 Maya 中开启遥控端口：

1. 打开 Maya 2022
2. 在脚本编辑器（Windows → General Editors → Script Editor）中粘贴执行：
```python
import maya.cmds as cmds
cmds.commandPort(name=':7778', sourceType='python')
```

> 提示：App 主界面顶部有这行命令，可复制粘贴。

---

## 使用流程

### 1. 添加渲染任务

点 **＋ 添加文件** → 选择 `.ma` 或 `.mb` 文件。

- `.ma` 文件会自动读取帧范围、分辨率、采样、渲染层
- `.mb` 文件需要手动点 **读取渲染层** 按钮获取渲染层列表
- 自动检测场景使用的渲染器（Redshift / Arnold）

### 2. 配置参数

| 参数 | 说明 |
|------|------|
| Maya 版本 | 选择用来渲染的 Maya 版本 |
| 渲染器 | Redshift 或 Arnold（采样参数自动切换） |
| 帧范围 | 起始帧 / 结束帧 / 步长 |
| 分辨率 | 预设 4K/2K/1080p/720p 或自定义 |
| 采样 | Redshift: Unified Max Samples + Threshold / Arnold: AA + Diffuse + Specular + ... |
| 输出路径 | 渲染文件存放目录 |
| 渲染层 | 勾选需要渲染的层（不勾选的不渲） |

### 3. 开始渲染

点 **▶ 开始渲染队列**，App 会自动：

1. 在 Maya 中打开文件 → 等待加载
2. 设置帧范围、分辨率、渲染器、采样、输出路径
3. 设置渲染层开关（只渲染勾选的层）
4. 提交 Maya BatchRender（Render Sequence）
5. 等待渲染完成
6. 打开空场景 → 继续下一个文件

---

## 队列管理

- **✎ 编辑** — 修改已添加任务的参数
- **✕ 删除** — 移除任务
- **↑ ↓** — 调整渲染顺序
- **右键** — 重试失败任务 / 编辑 / 删除

队列自动保存到 `jobs.json`，下次打开 App 还在。

---

## 脚本执行区

App 底部有脚本执行区域，可粘贴 Python 代码在 Maya 环境中执行，用于调试和测试。

---

## 常见问题

**Q: 连接 Maya 失败？**
A: 确认 Maya 已打开且执行了 `cmds.commandPort(name=':7778', sourceType='python')`。

**Q: 渲染层修改不生效？**
A: 确认使用的是 Maya 的 Render Setup 系统（非 Legacy 渲染层）。

**Q: 输出路径被覆盖了？**
A: App 会将输出路径设为 `你的路径/<Scene>/<RenderLayer>/<RenderLayer>`。

**Q: 支持 Redshift 吗？**
A: 支持。选择 Redshift 渲染器后，采样参数自动切换为 Unified Max Samples。
