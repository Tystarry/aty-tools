﻿# Maya Render Queue — 一键安装脚本
$ErrorActionPreference = 'Continue'

$AppDir = $PSScriptRoot
$InstallDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'ATY_Tools\MayaRenderQueue'

Write-Host ''
Write-Host '  =========================================='
Write-Host '    Maya 渲染队列 — 一键安装'
Write-Host '  =========================================='
Write-Host ''

# [1/3] 复制文件
Write-Host "  [1/3] 复制程序文件到 $InstallDir ..."
try {
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    robocopy $AppDir $InstallDir /E /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) {
        Write-Host '  [错误] 复制失败，请检查磁盘空间或权限'
        exit 1
    }
    Write-Host '        完成'
} catch {
    Write-Host "  [错误] 复制失败: $_"
    exit 1
}

# [2/3] 创建桌面快捷方式
Write-Host ''
Write-Host '  [2/3] 创建桌面快捷方式 ...'
try {
    $ws = New-Object -ComObject WScript.Shell
    $desktop = [Environment]::GetFolderPath('Desktop')
    $lnkPath = Join-Path $desktop 'Maya渲染队列.lnk'
    $sc = $ws.CreateShortcut($lnkPath)
    $sc.TargetPath = Join-Path $InstallDir 'run.bat'
    $sc.WorkingDirectory = $InstallDir
    $ico = Join-Path $InstallDir 'icon.ico'
    if (Test-Path $ico) { $sc.IconLocation = $ico }
    $sc.Save()
    Write-Host '        完成'
} catch {
    Write-Host "  [警告] 快捷方式创建失败: $_"
    Write-Host "         可以手动运行 $InstallDir\run.bat"
}

# [3/3] 检查 Maya
Write-Host ''
Write-Host '  [3/3] 检查 Maya 环境 ...'
$found = @()
$autodeskDir = Join-Path $env:ProgramFiles 'Autodesk'
if (Test-Path $autodeskDir) {
    Get-ChildItem $autodeskDir -Directory -Filter 'Maya*' | ForEach-Object {
        if (Test-Path (Join-Path $_.FullName 'bin\mayapy.exe')) {
            $found += $_.Name
        }
    }
}
if ($found.Count -gt 0) {
    Write-Host '        OK - 检测到以下 Maya 版本:'
    $found | ForEach-Object { Write-Host "          - $_" }
} else {
    Write-Host '        [警告] 未在默认路径检测到 Maya'
    Write-Host '               请确认 Maya 已安装'
}

Write-Host ''
Write-Host '  =========================================='
Write-Host '    安装完成！'
Write-Host '    双击桌面的「Maya渲染队列」图标启动'
Write-Host '  =========================================='
Write-Host ''
