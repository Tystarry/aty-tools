"""
GUI — PySide2 主窗口 + 任务编辑对话框 + 日志面板
"""
import os
import sys
from PySide2 import QtWidgets, QtCore, QtGui

from .theme import QT_STYLESHEET
from .job_model import RenderJob
from .executor import RenderExecutor
from .maya_detector import detect_renderer_from_file, read_scene_settings, parse_ma_settings


RES_PRESETS = [
    ("3840x2160 (4K)",   3840, 2160),
    ("2560x1440 (2K)",   2560, 1440),
    ("1920x1080 (1080p)",1920, 1080),
    ("1280x720 (720p)",  1280, 720),
    ("自定义",            None, None),
]

STATUS_LABELS = {
    "pending": "等待中",
    "running": "渲染中 ▶",
    "done":    "已完成 ✓",
    "error":   "错误 ✗",
}

STATUS_COLORS = {
    "pending": "#d4a844",
    "running": "#5a9ec9",
    "done":    "#6bbf6b",
    "error":   "#e05555",
}


# ════════════════════════════════════════════════════════════
# 主窗口
# ════════════════════════════════════════════════════════════

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, queue_manager, maya_versions):
        super().__init__()
        self.qm = queue_manager
        self.maya_versions = maya_versions
        self._ver_map = {v["version"]: v for v in maya_versions}

        self.setWindowTitle("Maya Render Queue")
        self.resize(960, 680)
        self.setMinimumSize(800, 500)

        # 消息队列：线程安全传递日志
        import queue
        self._msg_queue = queue.Queue()
        self._msg_timer = QtCore.QTimer()
        self._msg_timer.timeout.connect(self._drain_queue)
        self._msg_timer.start(300)  # 每 300ms 检查队列

        self.executor = RenderExecutor(
            queue_manager=self.qm,
            maya_versions=self._ver_map,
            log_callback=self._msg_queue.put,
            status_callback=lambda j, s: self._msg_queue.put(("status", j, s)),
        )

        self._build_ui()
        self._refresh_list()
        self.qm.set_on_change(lambda: QtCore.QTimer.singleShot(0, self._refresh_list))

    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QVBoxLayout(central)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)

        # ── 工具栏 ──
        toolbar = QtWidgets.QHBoxLayout()
        toolbar.setSpacing(4)

        btn_add = QtWidgets.QPushButton("＋ 添加文件")
        btn_add.clicked.connect(self._add_job)
        toolbar.addWidget(btn_add)

        btn_edit = QtWidgets.QPushButton("✎ 编辑")
        btn_edit.clicked.connect(self._edit_job)
        toolbar.addWidget(btn_edit)

        btn_del = QtWidgets.QPushButton("✕ 删除")
        btn_del.clicked.connect(self._delete_job)
        toolbar.addWidget(btn_del)

        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.VLine)
        toolbar.addWidget(line)

        btn_up = QtWidgets.QPushButton("↑ 上移")
        btn_up.clicked.connect(self._move_up)
        toolbar.addWidget(btn_up)

        btn_down = QtWidgets.QPushButton("↓ 下移")
        btn_down.clicked.connect(self._move_down)
        toolbar.addWidget(btn_down)

        toolbar.addStretch()

        self._count_label = QtWidgets.QLabel()
        toolbar.addWidget(self._count_label)

        layout.addLayout(toolbar)

        # ── Maya 连接提示 ──
        hint = QtWidgets.QLabel(
            'Maya: import maya.cmds as cmds; cmds.commandPort(name=":7778", sourceType="python")'
        )
        hint.setStyleSheet(
            "background-color: #2a2a3a; color: #d4a844; padding: 4px 10px;"
            "font-family: Consolas; font-size: 11px; border-radius: 3px;"
        )
        hint.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        layout.addWidget(hint)

        # ── 队列列表 ──
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(["名称", "渲染器", "帧范围", "尺寸", "Maya", "状态"])
        self.tree.setRootIsDecorated(False)
        self.tree.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tree.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tree.setAlternatingRowColors(True)
        self.tree.setColumnWidth(0, 260)
        self.tree.setColumnWidth(1, 80)
        self.tree.setColumnWidth(2, 80)
        self.tree.setColumnWidth(3, 70)
        self.tree.setColumnWidth(4, 60)
        self.tree.setColumnWidth(5, 80)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.tree.doubleClicked.connect(self._edit_job)
        self.tree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._on_context_menu)
        self._current_job_id = None
        self.tree.currentItemChanged.connect(self._on_current_changed)
        layout.addWidget(self.tree, 1)

        # ── 底部控制 ──
        ctrl = QtWidgets.QHBoxLayout()
        ctrl.setSpacing(8)

        self._start_btn = QtWidgets.QPushButton("▶ 开始渲染队列")
        self._start_btn.setObjectName("startBtn")
        self._start_btn.clicked.connect(self._start_queue)
        ctrl.addWidget(self._start_btn)

        self._stop_btn = QtWidgets.QPushButton("■ 停止")
        self._stop_btn.setObjectName("stopBtn")
        self._stop_btn.setEnabled(False)
        self._stop_btn.clicked.connect(self._stop_queue)
        ctrl.addWidget(self._stop_btn)

        ctrl.addStretch()

        self._progress_label = QtWidgets.QLabel()
        ctrl.addWidget(self._progress_label)

        layout.addLayout(ctrl)

        # ── 日志 ──
        log_group = QtWidgets.QGroupBox("日志")
        log_ly = QtWidgets.QVBoxLayout(log_group)
        log_ly.setContentsMargins(4, 4, 4, 4)

        self.log_text = QtWidgets.QPlainTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumBlockCount(2000)
        self.log_text.setFont(QtGui.QFont("Consolas", 9))
        log_ly.addWidget(self.log_text)

        layout.addWidget(log_group)

        # ── 脚本执行区域 ──
        script_group = QtWidgets.QGroupBox("脚本执行（粘贴 Python 代码，通过 mayapy 运行）")
        script_ly = QtWidgets.QVBoxLayout(script_group)
        script_ly.setContentsMargins(4, 4, 4, 4)

        script_row = QtWidgets.QHBoxLayout()
        self._script_edit = QtWidgets.QPlainTextEdit()
        self._script_edit.setPlaceholderText("粘贴 Python 脚本...")
        self._script_edit.setMaximumBlockCount(100)
        self._script_edit.setFont(QtGui.QFont("Consolas", 9))
        self._script_edit.setFixedHeight(60)
        script_row.addWidget(self._script_edit, 1)

        btn_run = QtWidgets.QPushButton("▶ 执行")
        btn_run.clicked.connect(self._run_script)
        btn_run.setFixedWidth(70)
        btn_run.setFixedHeight(60)
        script_row.addWidget(btn_run)

        script_ly.addLayout(script_row)
        layout.addWidget(script_group)

        # 启动日志
        self._append_log("Maya Render Queue 启动")
        self._append_log(f"检测到 Maya 版本: {[v['version'] for v in self.maya_versions]}")

    def _drain_queue(self):
        while not self._msg_queue.empty():
            try:
                msg = self._msg_queue.get_nowait()
                if isinstance(msg, tuple) and len(msg) == 3 and msg[0] == "status":
                    self.qm.set_status(msg[1], msg[2])
                elif isinstance(msg, str):
                    self.log_text.appendPlainText(msg)
            except:
                pass

    def _append_log(self, msg):
        self._msg_queue.put(msg)

    def _run_script(self):
        """在 mayapy 中执行用户粘贴的脚本，输出到日志"""
        code = self._script_edit.toPlainText().strip()
        if not code:
            return

        mayapy = None
        for mv in self.maya_versions:
            p = mv.get("mayapy", "")
            if os.path.isfile(p):
                mayapy = p
                break
        if not mayapy:
            self._append_log("[脚本] 错误: 未找到 mayapy")
            return

        self._append_log("[脚本] === 执行 ===")
        import subprocess
        import os as _os

        _log_dir = _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), "logs")
        _os.makedirs(_log_dir, exist_ok=True)
        script_path = _os.path.join(_log_dir, "_user_script.py")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(code)

        try:
            proc = subprocess.run(
                [mayapy, script_path],
                capture_output=True, text=True, timeout=60,
            )
            out = (proc.stdout or "").strip()
            err = (proc.stderr or "").strip()
            if out:
                for line in out.split("\n")[:100]:
                    self._append_log(f"[脚本] {line}")
            if err:
                for line in err.split("\n")[:50]:
                    self._append_log(f"[脚本][ERR] {line}")
            if not out and not err:
                self._append_log("[脚本] (无输出)")
            self._append_log(f"[脚本] 退出码: {proc.returncode}")
        except subprocess.TimeoutExpired:
            self._append_log("[脚本] 超时 (60s)")
        except Exception as e:
            self._append_log(f"[脚本] 异常: {e}")

    def _refresh_list(self, *args):
        self.tree.clear()
        jobs = self.qm.all
        self._job_order = [j.id for j in jobs]  # 并行列表：按行号存 job ID

        for j in jobs:
            item = QtWidgets.QTreeWidgetItem()
            item.setText(0, j.name if j.name else j.file_name)
            item.setText(1, j.renderer.capitalize())
            item.setText(2, j.frame_range_label)
            item.setText(3, j.resolution_label)
            item.setText(4, j.maya_version)

            status_text = STATUS_LABELS.get(j.status, j.status)
            item.setText(5, status_text)

            color = STATUS_COLORS.get(j.status, "#e0e0e0")
            item.setForeground(5, QtGui.QColor(color))

            self.tree.addTopLevelItem(item)

        self._count_label.setText(f"共 {len(jobs)} 个任务")

        running = self.executor.is_running()
        has_pending = any(j.status == "pending" for j in jobs)
        self._start_btn.setEnabled(has_pending and not running)
        self._stop_btn.setEnabled(running)

        done = sum(1 for j in jobs if j.status in ("done", "error"))
        if running and jobs:
            self._progress_label.setText(f"进度: {done}/{len(jobs)}")
        elif not running and jobs:
            self._progress_label.setText(f"就绪: {len(jobs)} 个任务")
        else:
            self._progress_label.setText("")

    def _on_job_status(self, job_id, status):
        self.qm.set_status(job_id, status)

    def _on_context_menu(self, pos):
        ids = self._selected_ids()
        if not ids:
            return
        job = self.qm.get(ids[0])
        if not job:
            return
        menu = QtWidgets.QMenu(self)
        if job.status in ("error", "done"):
            act_retry = menu.addAction("重试")
            act_retry.triggered.connect(lambda: self._retry_job(ids[0]))
        if job.status == "running":
            act_stop = menu.addAction("停止")
            act_stop.triggered.connect(lambda: self._stop_queue())
        menu.addSeparator()
        act_edit = menu.addAction("编辑")
        act_edit.triggered.connect(self._edit_job)
        act_del = menu.addAction("删除")
        act_del.triggered.connect(self._delete_job)
        menu.exec_(self.tree.mapToGlobal(pos))

    def _retry_job(self, job_id):
        self.qm.set_status(job_id, "pending")
        self._append_log(f"[重试] {self.qm.get(job_id).name}")

    def _on_current_changed(self, current, previous):
        if current:
            idx = self.tree.indexOfTopLevelItem(current)
            if 0 <= idx < len(self._job_order):
                self._current_job_id = self._job_order[idx]
            else:
                self._current_job_id = None
        else:
            self._current_job_id = None

    def _selected_ids(self):
        ids = []
        for item in self.tree.selectedItems():
            idx = self.tree.indexOfTopLevelItem(item)
            if 0 <= idx < len(self._job_order):
                ids.append(self._job_order[idx])
        if not ids and self._current_job_id:
            ids.append(self._current_job_id)
        return ids

    def _add_job(self):
        dialog = JobEditDialog(self, self.maya_versions, title="添加渲染任务")
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            self.qm.add(dialog.result)
            self._append_log(f"[添加] {dialog.result.name}")

    def _edit_job(self):
        ids = self._selected_ids()
        if not ids:
            QtWidgets.QMessageBox.information(self, "提示", "请先在队列中选择一个任务")
            return
        job = self.qm.get(ids[0])
        if not job:
            return
        dialog = JobEditDialog(self, self.maya_versions, job=job, title="编辑渲染任务")
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            r = dialog.result
            self.qm.update(job.id,
                name=r.name, file_path=r.file_path,
                maya_version=r.maya_version, renderer=r.renderer,
                start_frame=r.start_frame, end_frame=r.end_frame,
                step=r.step, width=r.width, height=r.height,
                rs_samples=r.rs_samples, rs_threshold=r.rs_threshold,
                arnold_aa=r.arnold_aa, arnold_diffuse=r.arnold_diffuse,
                arnold_specular=r.arnold_specular,
                arnold_transmission=r.arnold_transmission,
                arnold_sss=r.arnold_sss, arnold_volume=r.arnold_volume,
                output_path=r.output_path, render_layers=r.render_layers,
            )
            self._append_log(f"[编辑] {r.name}")

    def _delete_job(self):
        ids = self._selected_ids()
        if not ids:
            QtWidgets.QMessageBox.information(self, "提示", "请先在队列中选择一个任务")
            return
        reply = QtWidgets.QMessageBox.question(
            self, "确认删除", f"确定要删除选中的 {len(ids)} 个任务吗？",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        )
        if reply == QtWidgets.QMessageBox.Yes:
            self.qm.remove_many(ids)

    def _move_up(self):
        ids = self._selected_ids()
        if ids: self.qm.move_up(ids[0])

    def _move_down(self):
        ids = self._selected_ids()
        if ids: self.qm.move_down(ids[0])

    def _start_queue(self):
        if self.executor.is_running(): return
        pending = self.qm.pending
        if not pending:
            QtWidgets.QMessageBox.information(self, "提示", "没有待渲染的任务")
            return
        self._append_log("=" * 50)
        self.executor.start()
        self._refresh_list()

    def _stop_queue(self):
        self.executor.stop()
        self._refresh_list()

    def closeEvent(self, event):
        if self.executor.is_running():
            reply = QtWidgets.QMessageBox.question(
                self, "确认退出", "有任务正在渲染中，确定要退出吗？",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            )
            if reply != QtWidgets.QMessageBox.Yes:
                event.ignore()
                return
            self.executor.stop()
        event.accept()


# ════════════════════════════════════════════════════════════
# 任务编辑对话框
# ════════════════════════════════════════════════════════════

class JobEditDialog(QtWidgets.QDialog):
    def __init__(self, parent, maya_versions, job=None, title="编辑任务"):
        super().__init__(parent)
        self.maya_versions = maya_versions
        self.job = job
        self.result = None

        self.setWindowTitle(title)
        self.setMinimumWidth(550)
        self.setModal(True)

        self._build_form()
        if job:
            self._fill_from_job()

    def _build_form(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(16, 14, 16, 14)

        # ── 滚动区域（内容多的时候） ──
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        inner = QtWidgets.QWidget()
        form = QtWidgets.QVBoxLayout(inner)
        form.setSpacing(8)

        def add_row(label_text, widget, parent_layout=None):
            row = QtWidgets.QHBoxLayout()
            lbl = QtWidgets.QLabel(label_text)
            lbl.setFixedWidth(80)
            row.addWidget(lbl)
            row.addWidget(widget, 1)
            (parent_layout or form).addLayout(row)

        def add_label(text):
            lbl = QtWidgets.QLabel(text)
            lbl.setStyleSheet("font-weight: bold; color: #aaa; margin-top: 4px;")
            (form).addWidget(lbl)

        # ── Maya 文件 ──
        add_label("Maya 文件")
        path_row = QtWidgets.QHBoxLayout()
        self._file_edit = QtWidgets.QLineEdit()
        self._file_edit.setPlaceholderText("选择 .ma 或 .mb 文件...")
        path_row.addWidget(self._file_edit, 1)
        btn_browse = QtWidgets.QPushButton("浏览...")
        btn_browse.clicked.connect(self._browse_file)
        path_row.addWidget(btn_browse)
        form.addLayout(path_row)

        btn_load_layers = QtWidgets.QPushButton("读取渲染层")
        btn_load_layers.clicked.connect(self._load_render_layers)
        form.addWidget(btn_load_layers)

        # ── 名称 ──
        self._name_edit = QtWidgets.QLineEdit()
        add_row("任务名称", self._name_edit)

        # ── Maya 版本 + 渲染器 ──
        ver_row = QtWidgets.QHBoxLayout()
        ver_row.addWidget(QtWidgets.QLabel("Maya 版本"))
        self._maya_cb = QtWidgets.QComboBox()
        ver_list = [v["version"] for v in self.maya_versions] or ["2022"]
        self._maya_cb.addItems(ver_list)
        self._maya_cb.setFixedWidth(80)
        ver_row.addWidget(self._maya_cb)
        ver_row.addSpacing(20)
        ver_row.addWidget(QtWidgets.QLabel("渲染器"))
        self._renderer_cb = QtWidgets.QComboBox()
        self._renderer_cb.addItems(["redshift", "arnold"])
        self._renderer_cb.setFixedWidth(100)
        self._renderer_cb.currentIndexChanged.connect(self._on_renderer_changed)
        ver_row.addWidget(self._renderer_cb)
        ver_row.addStretch()
        form.addLayout(ver_row)

        # ── 帧范围 ──
        add_label("帧范围")
        fr_row = QtWidgets.QHBoxLayout()
        fr_row.addWidget(QtWidgets.QLabel("起始"))
        self._start_spin = QtWidgets.QSpinBox()
        self._start_spin.setRange(0, 99999)
        self._start_spin.setValue(1)
        fr_row.addWidget(self._start_spin)
        fr_row.addWidget(QtWidgets.QLabel("结束"))
        self._end_spin = QtWidgets.QSpinBox()
        self._end_spin.setRange(0, 99999)
        self._end_spin.setValue(100)
        fr_row.addWidget(self._end_spin)
        fr_row.addWidget(QtWidgets.QLabel("步长"))
        self._step_spin = QtWidgets.QDoubleSpinBox()
        self._step_spin.setRange(0.1, 100)
        self._step_spin.setValue(1.0)
        self._step_spin.setFixedWidth(70)
        fr_row.addWidget(self._step_spin)
        fr_row.addStretch()
        form.addLayout(fr_row)

        # ── 分辨率 ──
        res_row = QtWidgets.QHBoxLayout()
        res_row.addWidget(QtWidgets.QLabel("分辨率"))
        self._res_cb = QtWidgets.QComboBox()
        for label, _, _ in RES_PRESETS:
            self._res_cb.addItem(label)
        self._res_cb.setCurrentIndex(2)
        self._res_cb.currentIndexChanged.connect(self._on_res_preset)
        res_row.addWidget(self._res_cb)
        res_row.addWidget(QtWidgets.QLabel("W:"))
        self._w_spin = QtWidgets.QSpinBox()
        self._w_spin.setRange(1, 16384)
        self._w_spin.setValue(1920)
        res_row.addWidget(self._w_spin)
        res_row.addWidget(QtWidgets.QLabel("H:"))
        self._h_spin = QtWidgets.QSpinBox()
        self._h_spin.setRange(1, 16384)
        self._h_spin.setValue(1080)
        res_row.addWidget(self._h_spin)
        res_row.addStretch()
        form.addLayout(res_row)

        # ── 采样（按渲染器切换） ──
        add_label("采样设置")
        self._samples_stack = QtWidgets.QStackedWidget()

        # -- Redshift 采样 --
        rs_widget = QtWidgets.QWidget()
        rs_ly = QtWidgets.QHBoxLayout(rs_widget)
        rs_ly.setContentsMargins(0, 0, 0, 0)
        rs_ly.addWidget(QtWidgets.QLabel("Unified Max Samples"))
        self._rs_samples = QtWidgets.QSpinBox()
        self._rs_samples.setRange(1, 99999)
        self._rs_samples.setValue(256)
        self._rs_samples.setFixedWidth(90)
        rs_ly.addWidget(self._rs_samples)
        rs_ly.addWidget(QtWidgets.QLabel("Threshold"))
        self._rs_threshold = QtWidgets.QDoubleSpinBox()
        self._rs_threshold.setRange(0.001, 1.0)
        self._rs_threshold.setValue(0.01)
        self._rs_threshold.setDecimals(3)
        self._rs_threshold.setSingleStep(0.005)
        self._rs_threshold.setFixedWidth(80)
        rs_ly.addWidget(self._rs_threshold)
        rs_ly.addStretch()
        self._samples_stack.addWidget(rs_widget)

        # -- Arnold 采样 --
        ar_widget = QtWidgets.QWidget()
        ar_ly = QtWidgets.QGridLayout(ar_widget)
        ar_ly.setContentsMargins(0, 0, 0, 0)
        self._arnold_spins = {}
        ar_fields = [
            ("AA",        "arnold_aa",     5),
            ("Diffuse",   "arnold_diffuse",  2),
            ("Specular",  "arnold_specular", 2),
            ("Transmission","arnold_transmission", 2),
            ("SSS",       "arnold_sss",      2),
            ("Volume",    "arnold_volume",   2),
        ]
        for i, (label, key, default) in enumerate(ar_fields):
            row, col = i // 2, (i % 2) * 2
            ar_ly.addWidget(QtWidgets.QLabel(label + ":"), row, col)
            spin = QtWidgets.QSpinBox()
            spin.setRange(0, 999)
            spin.setValue(default)
            spin.setFixedWidth(65)
            self._arnold_spins[key] = spin
            ar_ly.addWidget(spin, row, col + 1)
        self._samples_stack.addWidget(ar_widget)

        form.addWidget(self._samples_stack)

        # ── 输出路径 ──
        out_row = QtWidgets.QHBoxLayout()
        out_row.addWidget(QtWidgets.QLabel("输出路径"))
        self._out_edit = QtWidgets.QLineEdit()
        self._out_edit.setPlaceholderText("留空使用场景默认路径...")
        out_row.addWidget(self._out_edit, 1)
        btn_out = QtWidgets.QPushButton("浏览...")
        btn_out.clicked.connect(self._browse_out)
        out_row.addWidget(btn_out)
        form.addLayout(out_row)

        # ── 渲染层（勾选列表） ──
        add_label("渲染层（勾选需要渲染的层）")
        self._layers_list = QtWidgets.QListWidget()
        self._layers_list.setMaximumHeight(120)
        form.addWidget(self._layers_list)

        form.addStretch()

        scroll.setWidget(inner)
        layout.addWidget(scroll, 1)

        # ── 按钮 ──
        btn_row = QtWidgets.QHBoxLayout()
        btn_row.addStretch()
        btn_cancel = QtWidgets.QPushButton("取消")
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_cancel)
        btn_ok = QtWidgets.QPushButton("确认")
        btn_ok.setObjectName("startBtn")
        btn_ok.clicked.connect(self._confirm)
        btn_row.addWidget(btn_ok)
        layout.addLayout(btn_row)

        # 初始化渲染器对应的采样面板
        self._on_renderer_changed()

    # ── 渲染器切换 ──

    def _on_renderer_changed(self, idx=None):
        renderer = self._renderer_cb.currentText()
        if renderer == "redshift":
            self._samples_stack.setCurrentIndex(0)
        else:
            self._samples_stack.setCurrentIndex(1)

    # ── 预设分辨率 ──

    def _on_res_preset(self, idx):
        label = RES_PRESETS[idx][0]
        is_custom = (label == "自定义")
        self._w_spin.setEnabled(is_custom)
        self._h_spin.setEnabled(is_custom)
        for lb, w, h in RES_PRESETS:
            if lb == label and w is not None:
                self._w_spin.setValue(w)
                self._h_spin.setValue(h)
                return

    # ── 浏览文件 + 自动检测 ──

    def _browse_file(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "选择 Maya 场景文件", "",
            "Maya 文件 (*.ma *.mb);;所有文件 (*.*)",
        )
        if path:
            self._file_edit.setText(path)
            if not self._name_edit.text():
                self._name_edit.setText(os.path.splitext(os.path.basename(path))[0])
            # 自动读取场景设置
            self._auto_read_settings(path)

    # ── 自动读取场景设置 ──

    def _auto_read_settings(self, file_path=None):
        """选文件后快速读取：.ma 文本解析（瞬发），.mb 只推断渲染器"""
        file_path = file_path or self._file_edit.text().strip()
        if not file_path or not os.path.isfile(file_path):
            return

        # 从文件头快速推断渲染器
        inferred = detect_renderer_from_file(file_path)
        if inferred:
            idx = self._renderer_cb.findText(inferred)
            if idx >= 0:
                self._renderer_cb.setCurrentIndex(idx)

        # .ma 文件：文本解析帧范围、分辨率、采样（瞬发，不需要 mayapy）
        if file_path.lower().endswith('.ma'):
            settings = parse_ma_settings(file_path)
            if settings:
                self._apply_settings(settings)
        # .mb 文件：需要 mayapy，提示用户点"读取渲染层"
        else:
            if self._layers_list.count() == 0:
                # 先填默认渲染层
                self._layers_list.clear()
                item = QtWidgets.QListWidgetItem("masterLayer")
                item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
                item.setCheckState(QtCore.Qt.Checked)
                self._layers_list.addItem(item)

    def _apply_settings(self, settings):
        """把设置字典填入界面控件"""
        if "start_frame" in settings:
            self._start_spin.setValue(settings["start_frame"])
        if "end_frame" in settings:
            self._end_spin.setValue(settings["end_frame"])
        if "step" in settings:
            self._step_spin.setValue(float(settings["step"]))
        if "width" in settings:
            self._w_spin.setValue(settings["width"])
        if "height" in settings:
            self._h_spin.setValue(settings["height"])
        if "rs_samples" in settings:
            self._rs_samples.setValue(settings["rs_samples"])
        if "rs_threshold" in settings:
            self._rs_threshold.setValue(float(settings["rs_threshold"]))
        for key in self._arnold_spins:
            if key in settings:
                self._arnold_spins[key].setValue(settings[key])
        layers = settings.get("layers", ["masterLayer"])
        self._layers_list.clear()
        for layer in layers:
            item = QtWidgets.QListWidgetItem(layer)
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            item.setCheckState(QtCore.Qt.Checked)
            self._layers_list.addItem(item)
        self._on_renderer_changed()

    def _load_render_layers(self):
        """手动点击 — 用 mayapy 完整读取场景全部设置"""
        file_path = self._file_edit.text().strip()
        if not file_path or not os.path.isfile(file_path):
            QtWidgets.QMessageBox.warning(self, "警告", "请先选择有效的 Maya 文件")
            return

        maya_ver = self._maya_cb.currentText()
        mayapy_path = None
        for mv in self.maya_versions:
            if mv["version"] == maya_ver:
                mayapy_path = mv["mayapy"]
                break
        if not mayapy_path or not os.path.isfile(mayapy_path):
            # 尝试任意可用版本的 mayapy
            for mv in self.maya_versions:
                if os.path.isfile(mv.get("mayapy", "")):
                    mayapy_path = mv["mayapy"]
                    break
        if not mayapy_path:
            QtWidgets.QMessageBox.warning(self, "警告", "未找到可用的 mayapy")
            return

        # 先合并 .ma 文本解析结果
        settings = {}
        if file_path.lower().endswith('.ma'):
            settings = parse_ma_settings(file_path)

        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            mp_settings = read_scene_settings(file_path, mayapy_path)
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self, "错误", f"读取异常: {e}")
            return
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()

        for k, v in (mp_settings or {}).items():
            if k not in settings or not settings[k]:
                settings[k] = v

        if not settings or not settings.get("layers"):
            # 至少填上默认渲染层
            if not settings:
                settings = {}
            if not settings.get("layers"):
                settings["layers"] = ["masterLayer"]
            self._apply_settings(settings)
            QtWidgets.QMessageBox.information(
                self, "提示",
                "只读取到部分设置。\n"
                "渲染层已默认设为 masterLayer。\n"
                "帧范围/分辨率/采样请手动设置。\n\n"
                "（.mb 文件且渲染器插件加载失败时可能出现此情况）"
            )
            return

        # 渲染器
        if "renderer" in settings:
            idx = self._renderer_cb.findText(settings["renderer"])
            if idx >= 0:
                self._renderer_cb.setCurrentIndex(idx)

        self._apply_settings(settings)

    def _get_checked_layers(self):
        layers = []
        for i in range(self._layers_list.count()):
            item = self._layers_list.item(i)
            if item.checkState() == QtCore.Qt.Checked:
                layers.append(item.text())
        return layers if layers else ["masterLayer"]

    def _set_checked_layers(self, layer_list):
        """设置勾选（追加新层，勾选已有层）"""
        existing = {self._layers_list.item(i).text(): i
                    for i in range(self._layers_list.count())}
        for layer in layer_list:
            if layer in existing:
                self._layers_list.item(existing[layer]).setCheckState(QtCore.Qt.Checked)

    # ── 输出路径 ──

    def _browse_out(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "选择输出目录")
        if path:
            self._out_edit.setText(path)

    # ── 填充已有 job ──

    def _fill_from_job(self):
        j = self.job
        self._file_edit.setText(j.file_path)
        self._name_edit.setText(j.name)
        idx = self._maya_cb.findText(j.maya_version)
        if idx >= 0: self._maya_cb.setCurrentIndex(idx)
        idx = self._renderer_cb.findText(j.renderer)
        if idx >= 0: self._renderer_cb.setCurrentIndex(idx)
        self._start_spin.setValue(j.start_frame)
        self._end_spin.setValue(j.end_frame)
        self._step_spin.setValue(j.step)
        self._w_spin.setValue(j.width)
        self._h_spin.setValue(j.height)
        # 检查是否匹配预设
        matched = False
        for label, pw, ph in RES_PRESETS:
            if pw == j.width and ph == j.height:
                self._res_cb.setCurrentIndex(RES_PRESETS.index((label, pw, ph)))
                matched = True
                break
        if not matched:
            self._res_cb.setCurrentIndex(len(RES_PRESETS)-1)  # 自定义
        self._rs_samples.setValue(j.rs_samples)
        self._rs_threshold.setValue(j.rs_threshold)
        for key, spin in self._arnold_spins.items():
            val = getattr(j, key, 2)
            spin.setValue(val)
        self._out_edit.setText(j.output_path)

        # 渲染层：先填列表，再勾选
        self._layers_list.clear()
        for layer in j.render_layers or ["masterLayer"]:
            item = QtWidgets.QListWidgetItem(layer)
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            item.setCheckState(QtCore.Qt.Checked)
            self._layers_list.addItem(item)

        self._on_renderer_changed()

    # ── 确认 ──

    def _confirm(self):
        file_path = self._file_edit.text().strip()
        if not file_path:
            QtWidgets.QMessageBox.warning(self, "警告", "请选择 Maya 文件")
            return
        if not os.path.isfile(file_path):
            QtWidgets.QMessageBox.warning(self, "警告", f"文件不存在:\n{file_path}")
            return

        maya_ver = self._maya_cb.currentText()
        if not maya_ver and self.maya_versions:
            maya_ver = self.maya_versions[0]["version"]

        # 收集 Arnold 采样值
        ar_kwargs = {k: s.value() for k, s in self._arnold_spins.items()}

        self.result = RenderJob(
            id=self.job.id if self.job else None,
            name=self._name_edit.text().strip() or os.path.splitext(os.path.basename(file_path))[0],
            file_path=file_path,
            maya_version=maya_ver,
            renderer=self._renderer_cb.currentText(),
            start_frame=self._start_spin.value(),
            end_frame=self._end_spin.value(),
            step=self._step_spin.value(),
            width=self._w_spin.value(),
            height=self._h_spin.value(),
            rs_samples=self._rs_samples.value(),
            rs_threshold=self._rs_threshold.value(),
            **ar_kwargs,
            output_path=self._out_edit.text().strip(),
            render_layers=self._get_checked_layers(),
        )
        self.accept()
