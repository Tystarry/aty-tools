"""
渲染执行引擎 — 通过 Maya commandPort 控制已运行的 Maya
"""
import os, json, time, socket, threading, traceback

PORT = 7778
HOST = "127.0.0.1"


def _logs_dir():
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")


class RenderExecutor:
    def __init__(self, queue_manager, maya_versions, log_callback=None, status_callback=None):
        self.qm = queue_manager
        self.maya_versions = maya_versions
        self.log = log_callback or (lambda msg: None)
        self.on_status = status_callback or (lambda j, s: None)
        self._thread = None
        self._stop_flag = False
        self._sock = None

    def start(self):
        if self._thread and self._thread.is_alive():
            self.log("[警告] 已有渲染线程在运行")
            return
        self._stop_flag = False
        def _safe():
            try: self._run_queue()
            except Exception as e:
                self.log(f"[崩溃] {e}\n{traceback.format_exc()}")
        self._thread = threading.Thread(target=_safe, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_flag = True
        self.log("[RenderQueue] 停止...")
        try:
            if self._sock: self._sock.close()
        except: pass

    def is_running(self):
        return self._thread is not None and self._thread.is_alive()

    def _connect(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((HOST, PORT))
        self._sock = s

    def _cmd(self, code):
        if not self._sock: raise Exception("未连接")
        self._sock.sendall((code + "\n").encode("utf-8"))

    def _run_queue(self):
        jobs = [j for j in self.qm.all if j.status == "pending"]
        if not jobs:
            self.log("[RenderQueue] 没有待渲染的任务")
            return
        self.log(f"[RenderQueue] 连接 Maya...")
        try:
            self._connect()
            self.log("[RenderQueue] 已连接 Maya")
        except Exception as e:
            self.log(f"[RenderQueue] 连接失败: {e}")
            return

        total = len(jobs)
        self.log(f"[RenderQueue] 开始队列，共 {total} 个任务")
        self.log("-" * 50)
        for i, job in enumerate(jobs):
            if self._stop_flag:
                self.log("[RenderQueue] 队列已停止")
                break
            self.log(f"[{i+1}/{total}] {job.name}")
            try:
                self._run_single(job)
            except Exception as e:
                self.log(f"  [异常] {e}")
                self.on_status(job.id, "error")
        try: self._sock.close()
        except: pass
        self._sock = None
        self.log("-" * 50)
        self.log("[RenderQueue] 队列执行完毕")

    def _run_single(self, job):
        self.on_status(job.id, "running")
        t0 = time.time()
        r = job.renderer
        fp = job.file_path.replace("\\", "/")
        layers = job.render_layers or ["defaultRenderLayer"]

        # 1. 打开目标文件
        self.log(f"  [1/3] 打开: {os.path.basename(job.file_path)}")
        self._cmd(f"cmds.file(r'{fp}', open=True, force=True)")
        self.log("  等待加载 (60s)...")
        time.sleep(60)
        self.log("  就绪")

        # 2. 设置参数
        self.log("  [2/3] 设置参数...")
        for p in [
            f"cmds.setAttr('defaultRenderGlobals.startFrame', {job.start_frame})",
            f"cmds.setAttr('defaultRenderGlobals.endFrame', {job.end_frame})",
            f"cmds.setAttr('defaultRenderGlobals.byFrameStep', {job.step})",
            "cmds.setAttr('defaultRenderGlobals.animation', 1)",
            f"cmds.setAttr('defaultResolution.width', {job.width})",
            f"cmds.setAttr('defaultResolution.height', {job.height})",
            f"cmds.setAttr('defaultRenderGlobals.currentRenderer', '{r}', type='string')",
            "cmds.setAttr('defaultRenderGlobals.imageFormat', 51)",
        ]:
            self._cmd(p)
            time.sleep(0.2)

        if job.output_path:
            safe = job.output_path.replace("\\", "/")
            self._cmd(f"cmds.workspace(fileRuleEntry='{safe}')")
            self._cmd(f"cmds.setAttr('defaultRenderGlobals.imageFilePrefix', '{safe}/<Scene>/<RenderLayer>/<RenderLayer>', type='string')")
            time.sleep(0.2)

        if r == "redshift":
            self._cmd(f"cmds.setAttr('redshiftOptions.unifiedMaxSamples', {job.rs_samples})")
        elif r == "arnold":
            self._cmd("cmds.setAttr('defaultArnoldDriver.mergeAOVs', 1)")
            self._cmd(f"cmds.setAttr('defaultArnoldRenderOptions.AASamples', {job.arnold_aa})")
            self._cmd(f"cmds.setAttr('defaultArnoldRenderOptions.GIDiffuseSamples', {job.arnold_diffuse})")
            self._cmd(f"cmds.setAttr('defaultArnoldRenderOptions.GISpecularSamples', {job.arnold_specular})")
            self._cmd(f"cmds.setAttr('defaultArnoldRenderOptions.GITransmissionSamples', {job.arnold_transmission})")
            self._cmd(f"cmds.setAttr('defaultArnoldRenderOptions.GISssSamples', {job.arnold_sss})")
            self._cmd(f"cmds.setAttr('defaultArnoldRenderOptions.GIVolumeSamples', {job.arnold_volume})")

        # 渲染层：写到临时文件让 Maya exec，避免转义和 scope 问题
        py_path = os.path.join(_logs_dir(), f"layers_{job.id}.py").replace("\\", "/")
        with open(py_path, "w", encoding="utf-8") as f:
            f.write(
                f"import maya.cmds as cmds\n"
                f"import maya.app.renderSetup.model.renderSetup as _rs\n"
                f"_rql = {json.dumps(layers)}\n"
                f"_all = _rs.instance().getRenderLayers()\n"
                f"for _l in (_all or []):\n"
                f"    try:\n"
                f"        _l.setRenderable(_l.name() in _rql)\n"
                f"    except Exception as _e:\n"
                f"        cmds.warning('layer error: ' + str(_e))\n"
                f"cmds.file(modified=True)\n"
            )
        self._cmd(f"exec(open(r'{py_path}', encoding='utf-8').read())")
        time.sleep(2)

        # 3. 保存 + 提交渲染 + 等完成
        self.log("  保存并提交渲染...")
        # 渲染完成标记：postRenderMel 创建 done 文件
        done_file = os.path.join(_logs_dir(), f"done_{job.id}.txt").replace("\\", "/")
        try: os.remove(done_file)
        except: pass
        mel_val = f'python("open(r\'{done_file}\', \'w\').close()")'
        self._cmd(f"cmds.setAttr('defaultRenderGlobals.postRenderMel', {repr(mel_val)}, type='string')")
        time.sleep(1)
        self._cmd("cmds.file(save=True, force=True)")
        time.sleep(3)
        self.log(f"  [3/3] BatchRender: {r}")
        if r == "arnold":
            self._cmd("import maya.mel as _mel; _mel.eval('BatchRender')")
        elif r == "redshift":
            self._cmd("import maya.mel as _mel; _mel.eval('rsRender -batch -render;')")

        # 等完成标记文件出现
        self.log(f"  等待渲染完成...")
        waited = 0
        while waited < 28800 and not self._stop_flag:
            time.sleep(30)
            waited += 30
            if os.path.isfile(done_file):
                self.log("  渲染完成")
                os.remove(done_file)
                break

        # 开空场景清状态
        self.log("  打开空场景...")
        self._cmd("cmds.file(new=True, force=True)")
        time.sleep(2)

        elapsed = time.time() - t0
        self.log(f"  完成，耗时 {self._ft(elapsed)}")
        self.on_status(job.id, "done")

    @staticmethod
    def _ft(seconds):
        h, r = divmod(int(seconds), 3600)
        m, s = divmod(r, 60)
        if h: return f"{h}h{m}m{s}s"
        if m: return f"{m}m{s}s"
        return f"{s}s"
