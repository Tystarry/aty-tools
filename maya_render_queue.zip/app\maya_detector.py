"""
Maya 版本和渲染器检测
自动扫描已安装的 Maya 版本和对应的渲染器插件
"""
import os
import re
import subprocess


AUTODESK_DIR = "C:\\Program Files\\Autodesk"


def detect_maya_versions():
    """扫描 Autodesk 目录，返回已安装的 Maya 版本列表，按版本号降序"""
    versions = []
    if not os.path.isdir(AUTODESK_DIR):
        return versions

    for entry in os.listdir(AUTODESK_DIR):
        m = re.match(r"^Maya(\d{4})$", entry)
        if not m:
            continue
        ver = m.group(1)
        mayabatch = os.path.join(AUTODESK_DIR, entry, "bin", "mayabatch.exe")
        if os.path.isfile(mayabatch):
            versions.append({
                "version": ver,
                "path": os.path.join(AUTODESK_DIR, entry),
                "mayabatch": mayabatch,
                "render_exe": os.path.join(AUTODESK_DIR, entry, "bin", "Render.exe"),
                "mayapy": os.path.join(AUTODESK_DIR, entry, "bin", "mayapy.exe"),
            })
    versions.sort(key=lambda v: v["version"], reverse=True)
    return versions


def detect_renderer_from_file(file_path):
    """解析 Maya 场景文件头部，推断使用的渲染器"""
    if not file_path or not os.path.isfile(file_path):
        return None

    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".ma":
        return _detect_from_ma(file_path)
    elif ext == ".mb":
        return None  # 二进制文件无法直接解析

    return None


def _detect_from_ma(file_path):
    """解析 .ma 文件头部 requires 语句"""
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            head = "".join(f.readline() for _ in range(300))
    except Exception:
        return None

    if 'requires "redshift4maya"' in head:
        return "redshift"
    elif 'requires "mtoa"' in head:
        return "arnold"
    return None


def detect_renderer_version(maya_info, renderer):
    """通过 mayapy 查询已安装渲染器插件的版本号"""
    if renderer == "redshift":
        plugin = "redshift4maya"
    elif renderer == "arnold":
        plugin = "mtoa"
    else:
        return ""

    script = (
        "import maya.standalone; "
        "maya.standalone.initialize(name='python'); "
        "import maya.cmds as cmds; "
        f"print(cmds.pluginInfo('{plugin}', query=True, version=True))"
    )

    try:
        result = subprocess.run(
            [maya_info["mayapy"], "-c", script],
            capture_output=True, text=True, timeout=30
        )
        # 输出可能是多行，取最后一行有效内容
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if line and not line.startswith("Error") and not line.startswith("Warning"):
                return line
        return ""
    except Exception:
        return ""


def read_scene_settings(file_path, mayapy_path):
    """通过 mayapy standalone 一次性读取 Maya 场景的所有渲染设置

    优先使用指定的 mayapy；如果渲染器插件加载失败，自动尝试 Maya 2024 的 mayapy。
    """
    best = {}
    for mayapy in _get_mayapy_candidates(mayapy_path):
        result = _try_read_settings(file_path, mayapy)
        if not result:
            continue
        # 合并结果（后面的补充前面的缺失字段）
        for k, v in result.items():
            if k not in best or best[k] is None:
                best[k] = v
        # 如果已经拿到所有关键数据，提前返回
        if best.get("layers") and best.get("renderer"):
            renderer = best["renderer"]
            if renderer == "redshift" and "rs_samples" in best:
                break
            if renderer == "arnold" and "arnold_aa" in best:
                break
            # 如果已有 layers 和 renderer 但不是 rs/arnold，也够了
            if renderer not in ("redshift", "arnold"):
                break
    return best


def _get_mayapy_candidates(preferred):
    # 优先用 2024 的 mayapy（能加载 Redshift），指定版本作为备选
    mayapy_2024 = r"C:\Program Files\Autodesk\Maya2024\bin\mayapy.exe"
    if os.path.isfile(mayapy_2024):
        yield mayapy_2024
    if preferred != mayapy_2024 and os.path.isfile(preferred):
        yield preferred


def _try_read_settings(file_path, mayapy_path):
    script = r"""
import json, sys
import maya.standalone
maya.standalone.initialize(name='python')
import maya.cmds as cmds

cmds.file(r'%s', open=True, force=True)

# 加载插件
for plugin in ['redshift4maya', 'mtoa']:
    try:
        if not cmds.pluginInfo(plugin, query=True, loaded=True):
            cmds.loadPlugin(plugin)
    except:
        pass

result = {}

# -- 帧范围 --
try:
    result['start_frame'] = int(cmds.getAttr('defaultRenderGlobals.startFrame'))
    result['end_frame']   = int(cmds.getAttr('defaultRenderGlobals.endFrame'))
    result['step']        = cmds.getAttr('defaultRenderGlobals.byFrameStep')
except: pass

# -- 分辨率 --
try:
    result['width']  = int(cmds.getAttr('defaultResolution.width'))
    result['height'] = int(cmds.getAttr('defaultResolution.height'))
except: pass

# -- 当前渲染器 --
try:
    result['renderer'] = cmds.getAttr('defaultRenderGlobals.currentRenderer')
except: pass

# -- 激活渲染器以触发选项节点创建 --
current_renderer = result.get('renderer', '')
if current_renderer:
    try:
        cmds.setAttr('defaultRenderGlobals.currentRenderer', current_renderer, type='string')
    except: pass

# -- 渲染层 (Render Setup + legacy) --
layers = []
try:
    import maya.app.renderSetup.model.renderSetup as rs
    rs_instance = rs.instance()
    for rl in (rs_instance.getRenderLayers() or []):
        name = rl.name()
        if name not in ('defaultRenderLayer',):
            layers.append(name)
except: pass
if not layers:
    try:
        for l in sorted(cmds.ls(type='renderLayer') or []):
            if l not in ('defaultRenderLayer', 'masterLayer'):
                layers.append(l)
    except: pass
if not layers:
    layers = ['masterLayer']
result['layers'] = layers

# -- Redshift 采样 --
try:
    result['rs_samples']   = int(cmds.getAttr('redshiftOptions.unifiedMaxSamples'))
except: pass
try:
    result['rs_threshold'] = cmds.getAttr('redshiftOptions.adaptiveErrorThreshold')
except: pass

# -- Arnold 采样 --
try: result['arnold_aa'] = int(cmds.getAttr('defaultArnoldRenderOptions.AASamples'))
except: pass
try: result['arnold_diffuse'] = int(cmds.getAttr('defaultArnoldRenderOptions.GIDiffuseSamples'))
except: pass
try: result['arnold_specular'] = int(cmds.getAttr('defaultArnoldRenderOptions.GISpecularSamples'))
except: pass
try: result['arnold_transmission'] = int(cmds.getAttr('defaultArnoldRenderOptions.GITransmissionSamples'))
except: pass
try: result['arnold_sss'] = int(cmds.getAttr('defaultArnoldRenderOptions.GISssSamples'))
except: pass
try: result['arnold_volume'] = int(cmds.getAttr('defaultArnoldRenderOptions.GIVolumeSamples'))
except: pass

print('SCENE_SETTINGS:' + json.dumps(result))
""" % file_path.replace("\\", "/")

    # 写临时脚本文件（避免 -c 的 Unicode 命令行编码问题）
    _log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
    os.makedirs(_log_dir, exist_ok=True)
    script_path = os.path.join(_log_dir, "_read_settings.py")
    with open(script_path, "w", encoding="utf-8") as f:
        f.write(script)

    try:
        proc = subprocess.run(
            [mayapy_path, script_path],
            capture_output=True, text=True, timeout=120,
        )
        combined = (proc.stdout or "") + "\n" + (proc.stderr or "")
        for line in combined.split("\n"):
            line = line.strip()
            if line.startswith("SCENE_SETTINGS:"):
                import json as _json
                return _json.loads(line[len("SCENE_SETTINGS:"):])
        # 失败日志
        log_path = os.path.join(_log_dir, "read_fail.log")
        with open(log_path, "w", encoding="utf-8", errors="replace") as f:
            f.write(f"mayapy: {mayapy_path}\nfile: {file_path}\n")
            f.write("--- STDOUT ---\n" + (proc.stdout or "")[:2000] + "\n")
            f.write("--- STDERR ---\n" + (proc.stderr or "")[:2000] + "\n")
        return {}
    except Exception as e:
        with open(os.path.join(_log_dir, "read_exception.log"), "w") as f:
            f.write(str(e))
        return {}


def parse_ma_settings(file_path):
    """从 .ma 文件文本中直接解析渲染设置（不需要 mayapy）

    支持 Redshift 和 Arnold 的采样参数，以及帧范围、分辨率、渲染层。
    速度很快（纯文本解析），用于 .ma 文件。
    """
    if not file_path.lower().endswith('.ma'):
        return {}

    import re
    result = {}

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(500000)  # 只读前 500KB
    except Exception:
        return {}

    # -- 帧范围 --
    m = re.search(r'setAttr\s+"defaultRenderGlobals\.startFrame"\s+(\d+)', content)
    if m: result['start_frame'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultRenderGlobals\.endFrame"\s+(\d+)', content)
    if m: result['end_frame'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultRenderGlobals\.byFrameStep"\s+([\d.]+)', content)
    if m: result['step'] = float(m.group(1))

    # -- 分辨率 --
    m = re.search(r'setAttr\s+"defaultResolution\.width"\s+(\d+)', content)
    if m: result['width'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultResolution\.height"\s+(\d+)', content)
    if m: result['height'] = int(m.group(1))

    # -- 渲染器 --
    m = re.search(r'setAttr\s+"defaultRenderGlobals\.currentRenderer"\s+"(\w+)"', content)
    if m: result['renderer'] = m.group(1)

    # -- Redshift 采样 --
    m = re.search(r'setAttr\s+"\.unifiedMaxSamples"\s+(\d+)', content)
    if m: result['rs_samples'] = int(m.group(1))
    m = re.search(r'setAttr\s+"\.adaptiveErrorThreshold"\s+([\d.]+)', content)
    if m: result['rs_threshold'] = float(m.group(1))

    # -- Arnold 采样 --
    m = re.search(r'setAttr\s+"defaultArnoldRenderOptions\.AASamples"\s+(\d+)', content)
    if m: result['arnold_aa'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultArnoldRenderOptions\.GIDiffuseSamples"\s+(\d+)', content)
    if m: result['arnold_diffuse'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultArnoldRenderOptions\.GISpecularSamples"\s+(\d+)', content)
    if m: result['arnold_specular'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultArnoldRenderOptions\.GITransmissionSamples"\s+(\d+)', content)
    if m: result['arnold_transmission'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultArnoldRenderOptions\.GISssSamples"\s+(\d+)', content)
    if m: result['arnold_sss'] = int(m.group(1))
    m = re.search(r'setAttr\s+"defaultArnoldRenderOptions\.GIVolumeSamples"\s+(\d+)', content)
    if m: result['arnold_volume'] = int(m.group(1))

    # -- 渲染层（从 renderSetup 或 renderLayer 创建语句） --
    layers = []
    for m in re.finditer(r'createRenderLayer\s+"([^"]+)"', content):
        name = m.group(1)
        if name not in layers and name not in ('defaultRenderLayer',):
            layers.append(name)
    if not layers:
        # 也检查 renderSetup 创建的其他层
        for m in re.finditer(r'setAttr\s+"\.([^"]+)"\s+"[^"]*"[^;]*renderSetup', content):
            pass  # renderSetup 层的 ASCII 格式较复杂
    if not layers:
        layers = ['masterLayer']
    result['layers'] = layers

    return result


def get_render_layers(file_path, mayapy_path):
    """兼容旧接口：只读渲染层。优先用 mayapy，对 .ma 文件用文本解析"""
    # 先尝试文本解析（快）
    if file_path.lower().endswith('.ma'):
        parsed = parse_ma_settings(file_path)
        if parsed.get('layers'):
            return parsed['layers']
    # 回退到 mayapy
    settings = read_scene_settings(file_path, mayapy_path)
    return settings.get("layers", ["masterLayer"])


CACHE_FILE = None


def _get_cache_path():
    import os as _os
    return _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), "renderer_cache.json")


def load_cache():
    """加载渲染器版本缓存"""
    import json
    path = _get_cache_path()
    if os.path.isfile(path):
        try:
            with open(path, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_cache(cache):
    """保存渲染器版本缓存"""
    import json
    path = _get_cache_path()
    try:
        with open(path, "w") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
