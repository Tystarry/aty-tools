"""
RenderJob 数据模型
"""
import os
import uuid
import json
from datetime import datetime


class RenderJob:
    """单个渲染任务的配置数据"""

    def __init__(self, **kwargs):
        self.id          = kwargs.get("id") or str(uuid.uuid4())[:8]
        self.name        = kwargs.get("name", "未命名")
        self.file_path   = kwargs.get("file_path", "")
        self.maya_version    = kwargs.get("maya_version", "")
        self.renderer        = kwargs.get("renderer", "redshift")

        # ── 帧 / 分辨率 ──
        self.start_frame     = kwargs.get("start_frame", 1)
        self.end_frame       = kwargs.get("end_frame", 100)
        self.step            = kwargs.get("step", 1.0)
        self.width           = kwargs.get("width", 1920)
        self.height          = kwargs.get("height", 1080)

        # ── 采样（按渲染器分开） ──
        # Redshift
        self.rs_samples      = kwargs.get("rs_samples", 256)       # unified max
        self.rs_threshold    = kwargs.get("rs_threshold", 0.01)    # adaptive threshold
        # Arnold
        self.arnold_aa       = kwargs.get("arnold_aa", 5)          # AA samples
        self.arnold_diffuse  = kwargs.get("arnold_diffuse", 2)
        self.arnold_specular = kwargs.get("arnold_specular", 2)
        self.arnold_transmission = kwargs.get("arnold_transmission", 2)
        self.arnold_sss      = kwargs.get("arnold_sss", 2)
        self.arnold_volume   = kwargs.get("arnold_volume", 2)

        # ── 输出 ──
        self.output_path     = kwargs.get("output_path", "")
        self.render_layers   = kwargs.get("render_layers", ["masterLayer"])

        # ── 状态 ──
        self.status          = kwargs.get("status", "pending")
        self.created_at      = kwargs.get("created_at", datetime.now().isoformat())
        self._error_msg      = kwargs.get("_error_msg", "")

    @property
    def resolution_label(self):
        w, h = self.width, self.height
        if w == 3840 and h == 2160: return "4K"
        if w == 2560 and h == 1440: return "2K"
        if w == 1920 and h == 1080: return "1080p"
        if w == 1280 and h == 720:  return "720p"
        return f"{w}x{h}"

    @property
    def frame_range_label(self):
        s, e = self.start_frame, self.end_frame
        return f"{s}-{e}" if s != e else str(s)

    @property
    def file_name(self):
        return os.path.splitext(os.path.basename(self.file_path))[0] if self.file_path else ""

    @property
    def samples_label(self):
        if self.renderer == "redshift":
            return str(self.rs_samples)
        return f"AA{self.arnold_aa}"

    def to_dict(self):
        return {
            "id": self.id, "name": self.name, "file_path": self.file_path,
            "maya_version": self.maya_version, "renderer": self.renderer,
            "start_frame": self.start_frame, "end_frame": self.end_frame,
            "step": self.step, "width": self.width, "height": self.height,
            "rs_samples": self.rs_samples, "rs_threshold": self.rs_threshold,
            "arnold_aa": self.arnold_aa, "arnold_diffuse": self.arnold_diffuse,
            "arnold_specular": self.arnold_specular,
            "arnold_transmission": self.arnold_transmission,
            "arnold_sss": self.arnold_sss, "arnold_volume": self.arnold_volume,
            "output_path": self.output_path,
            "render_layers": self.render_layers,
            "status": self.status, "created_at": self.created_at,
            "_error_msg": self._error_msg,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(**d)

    def __repr__(self):
        return f"RenderJob({self.name}, {self.renderer}, {self.frame_range_label}, {self.status})"


def jobs_to_json(jobs: list) -> str:
    return json.dumps([j.to_dict() for j in jobs], ensure_ascii=False, indent=2)


def jobs_from_json(text: str) -> list:
    data = json.loads(text)
    return [RenderJob.from_dict(d) for d in data]
