"""
Maya Render Queue — 入口
启动方式:
    mayapy main.py
    或双击 run.bat
"""
import os
import sys

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from PySide2 import QtWidgets

from app.theme import QT_STYLESHEET
from app.queue_manager import QueueManager
from app.maya_detector import detect_maya_versions
from app.gui import MainWindow


def main():
    print("检测 Maya 安装...")
    maya_versions = detect_maya_versions()

    if not maya_versions:
        print("警告: 未检测到已安装的 Maya")
        maya_versions = [{
            "version": "2022",
            "path": "",
            "mayabatch": "mayabatch.exe",
            "render_exe": "",
            "mayapy": "",
        }]

    print(f"找到 {len(maya_versions)} 个 Maya 版本: {[v['version'] for v in maya_versions]}")

    qm = QueueManager()
    qm.load()
    print(f"已加载 {qm.count} 个渲染任务")

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(QT_STYLESHEET)

    window = MainWindow(qm, maya_versions)
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
