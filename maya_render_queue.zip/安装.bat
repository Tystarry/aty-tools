@echo off
chcp 65001 >nul
title Maya 渲染队列 — 一键安装

echo.
echo   ╔══════════════════════════════════════╗
echo   ║   Maya 渲染队列 — 一键安装            ║
echo   ╚══════════════════════════════════════╝
echo.

set "APP_DIR=%~dp0"
set "INSTALL_DIR=%USERPROFILE%\Documents\ATY_Tools\MayaRenderQueue"

echo   [1/3] 复制程序文件到 %INSTALL_DIR% ...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
xcopy /E /I /Y "%APP_DIR%*" "%INSTALL_DIR%" >nul 2>&1
echo        完成

echo.
echo   [2/3] 创建桌面快捷方式 ...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = [Environment]::GetFolderPath('Desktop'); $sc = $ws.CreateShortcut(\"$desktop\Maya渲染队列.lnk\"); $sc.TargetPath = '%INSTALL_DIR%\run.bat'; $sc.WorkingDirectory = '%INSTALL_DIR%'; $sc.IconLocation = '%INSTALL_DIR%\icon.ico'; $sc.Save()"
echo        完成

echo.
echo   [3/3] 检查 Maya 环境 ...
set "FOUND_MAYA="
for /d %%v in ("C:\Program Files\Autodesk\Maya*") do (
    if exist "%%v\bin\mayapy.exe" set "FOUND_MAYA=1"
)
if defined FOUND_MAYA (
    echo        ✓ 已检测到 Maya
    for /d %%v in ("C:\Program Files\Autodesk\Maya*") do (
        if exist "%%v\bin\mayapy.exe" echo          - %%v
    )
) else (
    echo        ⚠ 未检测到 Maya，请确认 Maya 安装在默认路径
)

echo.
echo   ╔══════════════════════════════════════╗
echo   ║   安装完成！                          ║
echo   ║   双击桌面的「Maya渲染队列」图标启动   ║
echo   ╚══════════════════════════════════════╝
echo.
pause
