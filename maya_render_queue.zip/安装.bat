@echo off
title Maya Render Queue - Install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
