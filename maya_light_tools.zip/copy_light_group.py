"""
Maya 脚本 — 复制灯光组时，自动为组下所有子灯光递增命名。

问题背景：
  Maya 复制整个灯光组（group）时，组下的子灯光有时不会自动递增命名，
  导致新复制的灯光与原始灯光重名，引发渲染层、AOV、灯光链接混乱。

用法：
  1. 在 Maya 视口或 Outliner 中选中要复制的灯光组/灯光
  2. 在 Script Editor (Python 标签页) 中运行：
        exec(open(r'D:\\zcy\\ai_ty\\copy_light_group.py', encoding='utf-8').read())
  3. 脚本复制整个层级，并确保所有子灯光获得不重复的名称

支持：
  - Maya 原生灯光：ambientLight, directionalLight, pointLight, spotLight, areaLight, volumeLight
  - Arnold 灯光：aiAreaLight, aiSkyDomeLight, aiLightPortal, aiPhotometricLight, aiMeshLight
  - 深层嵌套组（组中组中组...中的灯光）
  - 一次选中多个组同时复制
"""

import maya.cmds as cmds
import re


# ============================================================================
# 工具函数
# ============================================================================

def _is_light(node):
    """判断节点是否为灯光 transform（Maya原生 + Arnold + Redshift + V-Ray...）"""
    if not cmds.objExists(node):
        return False
    shapes = cmds.listRelatives(node, shapes=True, fullPath=True) or []
    for s in shapes:
        if 'light' in cmds.nodeType(s).lower():
            return True
    return False


def _get_lights_under(root):
    """
    递归获取 root 下所有灯光 transform 的全路径。
    返回: [full_path, ...]
    """
    result = []
    if _is_light(root):
        result.append(root)
    children = cmds.listRelatives(root, children=True, type='transform', fullPath=True) or []
    for child in children:
        result.extend(_get_lights_under(child))
    return result


def _short_name(full_path):
    """全路径 → 短名称"""
    return full_path.split('|')[-1]


def _make_unique_name(name):
    """
    确保名称在场景中唯一。
    如果 name 已存在，自动递增数字后缀。
    例：KeyLight → KeyLight1 → KeyLight2 ...
    """
    if not cmds.objExists(name):
        return name

    m = re.match(r'^(.*?)(\d*)$', name)
    base = m.group(1)
    suffix = m.group(2)

    num = int(suffix) if suffix else 1
    while cmds.objExists(f"{base}{num}"):
        num += 1
    return f"{base}{num}"


# ============================================================================
# 核心功能
# ============================================================================

def copy_light_group():
    """
    复制选中的灯光组，确保子灯光命名不重名。
    """
    sel = cmds.ls(selection=True, type='transform')
    if not sel:
        cmds.warning("[copy_light] 请先选中要复制的灯光组或灯光！")
        return

    results = []

    for root in sel:
        # 1. 记录原始灯光名称（短名），用于后续判断新灯光是否需要重命名
        orig_lights = _get_lights_under(root)
        orig_short_names = {_short_name(p) for p in orig_lights}
        print(f"[copy_light] 原始节点 '{_short_name(root)}' 下有 {len(orig_lights)} 个灯光")

        # 2. 执行复制
        try:
            new_nodes = cmds.duplicate(root, renameChildren=True)
        except Exception as e:
            cmds.warning(f"[copy_light] 复制失败: {e}")
            continue

        new_root = new_nodes[0]
        print(f"[copy_light] 新节点: '{_short_name(new_root)}'")

        # 3. 获取新组下的所有灯光（全路径）
        new_lights = _get_lights_under(new_root)

        # 4. 检查新灯光命名：如果短名称在原始灯光集合中，
        #    说明 Maya 没有正确递增 → 手动重命名
        renamed_count = 0
        for full_path in new_lights:
            sn = _short_name(full_path)
            if sn in orig_short_names:
                unique = _make_unique_name(sn)
                try:
                    actual = cmds.rename(full_path, unique)
                    print(f"[copy_light]   {sn} → {actual}")
                    renamed_count += 1
                except Exception as e:
                    cmds.warning(f"[copy_light]   重命名 {full_path} 失败: {e}")

        if renamed_count == 0:
            print(f"[copy_light]   Maya 已自动递增，无需修复 ✓")
        else:
            print(f"[copy_light]   共修复 {renamed_count} 个灯光命名")

        results.append(new_root)

    # 选中新创建的组
    if results:
        cmds.select(results)
    print(f"[copy_light] 完成！共复制 {len(results)} 个节点。")
    return results


# ============================================================================
# 入口
# ============================================================================

if __name__ == "__main__" or __name__ == "__builtin__":
    copy_light_group()
