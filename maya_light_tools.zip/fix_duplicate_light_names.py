"""
Maya 脚本 — 查找场景中重复命名的灯光，并自动修改为递增命名。

问题背景：
  复制灯光组或手动创建灯光时，可能出现多个灯光同名的情况。
  Maya 不会自动报错，但会导致渲染层、AOV、灯光链接等混乱。

用法：
  Maya Script Editor (Python 标签页) 中运行：
    exec(open(r'D:\\zcy\\ai_ty\\fix_duplicate_light_names.py', encoding='utf-8').read())

功能：
  - check_only()  — 仅检查并报告重复命名的灯光（不修改）
  - fix()          — 查找重复命名的灯光并自动重命名为递增序号
  - run()          — 一键检查 + 修复（默认入口）

重命名规则：
  场景中有 3 个名为 "SpotLight1" 的灯光 →
    SpotLight1  (保留第一个)
    SpotLight2  (第二个，自动找下一个可用编号)
    SpotLight3  (第三个)
"""

import maya.cmds as cmds
import re
from collections import Counter


# ============================================================================
# 工具函数
# ============================================================================

def _is_light_transform(node):
    """判断节点是否为灯光（支持 Maya 原生 + Arnold 灯光类型）"""
    if not cmds.objExists(node):
        return False
    shapes = cmds.listRelatives(node, shapes=True, fullPath=False) or []
    if not shapes:
        return False
    arnold_light_types = {'aiAreaLight', 'aiSkyDomeLight', 'aiLightPortal',
                          'aiPhotometricLight', 'aiMeshLight'}
    for s in shapes:
        node_type = cmds.nodeType(s)
        if node_type == 'light' or node_type in arnold_light_types:
            return True
    return False


def _is_referenced(node_name):
    """判断节点是否来自参考（reference）文件"""
    if not cmds.objExists(node_name):
        return True  # 不存在的节点跳过
    try:
        return cmds.referenceQuery(node_name, isNodeReferenced=True)
    except RuntimeError:
        return False


def _make_unique_name(name):
    """
    根据名称生成场景中唯一的递增名称。
    例如：KeyLight → 如果 KeyLight 已存在 → KeyLight1, KeyLight2...
    """
    if not cmds.objExists(name):
        return name

    m = re.match(r'^(.*?)(\d*)$', name)
    base = m.group(1)
    suffix = m.group(2)

    num = int(suffix) if suffix else 1
    while cmds.objExists(f"{base}{num}"):
        num += 1
    return f"{base}{num}"


# ============================================================================
# 核心功能
# ============================================================================

def check_only():
    """
    仅检查场景中的重复灯光命名，不执行任何修改。
    返回重复名称列表。
    """
    all_lights = cmds.ls(lights=True)

    # 过滤掉参考节点
    local_lights = [l for l in all_lights if not _is_referenced(l)]

    # 统计各名称出现次数
    name_counts = Counter(local_lights)
    duplicates = {name: count for name, count in name_counts.items() if count > 1}

    if not duplicates:
        print("[fix_light_name] ✅ 场景中没有重复命名的灯光。")
        return []

    print("[fix_light_name] ⚠ 发现以下重复命名的灯光：")
    print(f"  {'灯光名':<30} {'出现次数':>8}")
    print(f"  {'-'*30} {'-'*8}")
    for name, count in sorted(duplicates.items()):
        print(f"  {name:<30} {count:>8}")

    print(f"\n[fix_light_name] 共 {len(duplicates)} 个名称重复，涉及 {sum(duplicates.values())} 个灯光。")
    print("[fix_light_name] 运行 fix() 可自动修复。")
    return list(duplicates.keys())


def fix(dry_run=False):
    """
    修复场景中重复命名的灯光。

    对于每组重名灯光：
      - 保留第一个（序号最小或最先出现）
      - 其余重命名为同系列的下一个可用编号

    参数:
        dry_run: True = 仅预览将要执行的重命名（不修改场景）
    """
    all_lights = cmds.ls(lights=True, long=True)
    # 按短名称分组
    from collections import defaultdict
    name_groups = defaultdict(list)

    for full_path in all_lights:
        short_name = full_path.split('|')[-1]
        # 跳过参考节点
        if _is_referenced(short_name):
            continue
        name_groups[short_name].append(full_path)

    # 筛选出有重复的
    duplicates = {n: paths for n, paths in name_groups.items() if len(paths) > 1}

    if not duplicates:
        print("[fix_light_name] ✅ 场景中没有重复命名的灯光。")
        return 0

    print("[fix_light_name] 开始修复重复灯光命名...")
    print(f"[fix_light_name] 发现 {len(duplicates)} 组重名灯光\n")

    fixed_count = 0

    for short_name, paths in sorted(duplicates.items()):
        print(f"  重名组: '{short_name}' ({len(paths)} 个实例)")

        # 保留第一个，其余重命名
        keep = paths[0]
        to_rename = paths[1:]

        print(f"    保留: {keep}")

        for old_full in to_rename:
            # 生成唯一名称
            new_name = _make_unique_name(short_name)

            if dry_run:
                print(f"    [预览] {old_full} → {new_name}")
            else:
                try:
                    actual = cmds.rename(old_full, new_name)
                    print(f"    已重命名: {old_full.split('|')[-1]} → {actual}")
                    fixed_count += 1
                except Exception as e:
                    cmds.warning(f"[fix_light_name] 重命名失败: {old_full} → {new_name}, 错误: {e}")

        print()

    if dry_run:
        print(f"[fix_light_name] [预览模式] 将重命名 {fixed_count} 个灯光（未实际修改）")
    else:
        print(f"[fix_light_name] ✅ 修复完成！共重命名 {fixed_count} 个灯光。")

    return fixed_count


# ============================================================================
# 一键运行
# ============================================================================

def run():
    """
    一键检查 + 修复：先展示重复灯光，再执行重命名。
    """
    print("=" * 60)
    print("Maya 灯光重复命名检测与修复工具")
    print("=" * 60)
    print()

    dup_list = check_only()
    if not dup_list:
        return

    print()
    answer = input("[fix_light_name] 是否修复以上重复命名？(y/n): ").strip().lower()
    if answer == 'y':
        fix()
    else:
        print("[fix_light_name] 已取消，未做任何修改。")


# ============================================================================
# 入口
# ============================================================================

if __name__ == "__main__" or __name__ == "__builtin__":
    # 直接运行时：先检查再修复
    dup_list = check_only()
    if dup_list:
        print()
        fix()
