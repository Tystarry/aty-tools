"""
Maya 脚本 — 查找场景中重复命名的灯光，并自动修改为递增命名。

问题背景：
  复制灯光组或手动创建灯光时，可能出现多个灯光同名的情况。
  Maya 不会自动报错，但会导致渲染层、AOV、灯光链接等混乱。

用法：
  Maya Script Editor (Python 标签页) 中运行：
    exec(open(r'D:\\zcy\\ai_ty\\fix_duplicate_light_names.py', encoding='utf-8').read())

功能：
  - check_only()  — 仅检查并报告重复命名的灯光（不修改）
  - fix()          — 查找重复命名的灯光并自动重命名为递增序号
  - run()          — 一键检查 + 修复（默认入口）

链接保护：
  重命名后自动扫描场景中按旧名字符串引用灯光的属性
  （灯光链接、灯光组、表达式等），并自动更新为新名字，
  防止改灯光命名导致灯光链接丢失。

重命名规则：
  场景中有 3 个名为 "SpotLight1" 的灯光 →
    SpotLight1  (保留第一个)
    SpotLight2  (第二个，自动找下一个可用编号)
    SpotLight3  (第三个)
"""

import maya.cmds as cmds
import re
from collections import Counter


# ============================================================================
# 工具函数
# ============================================================================

def _is_light_transform(node):
    """判断节点是否为灯光（Maya原生 + Arnold + Redshift + V-Ray...）"""
    if not cmds.objExists(node):
        return False
    shapes = cmds.listRelatives(node, shapes=True, fullPath=True) or []
    for s in shapes:
        if 'light' in cmds.nodeType(s).lower():
            return True
    return False


def _get_all_lights():
    """获取场景中所有灯光 transform（Maya原生 + Arnold + Redshift + V-Ray...）"""
    lights = set()
    # Maya 原生灯光
    for l in (cmds.ls(lights=True, long=True) or []):
        lights.add(l)
    # 所有含 light/light 的 shape 类型（覆盖 Arnold/Redshift/V-Ray 等）
    all_shapes = cmds.ls(type='shape', long=True) or []
    for s in all_shapes:
        node_type = cmds.nodeType(s)
        if 'light' in node_type.lower():
            parent = cmds.listRelatives(s, parent=True, fullPath=True)
            if parent:
                lights.add(parent[0])
    return list(lights)


def _is_referenced(node_name):
    """判断节点是否来自参考（reference）文件"""
    if not cmds.objExists(node_name):
        return True  # 不存在的节点跳过
    try:
        return cmds.referenceQuery(node_name, isNodeReferenced=True)
    except RuntimeError:
        return False


def _make_unique_name(name):
    """
    根据名称生成场景中唯一的递增名称。
    例如：KeyLight → 如果 KeyLight 已存在 → KeyLight1, KeyLight2...
    """
    if not cmds.objExists(name):
        return name

    m = re.match(r'^(.*?)(\d*)$', name)
    base = m.group(1)
    suffix = m.group(2)

    num = int(suffix) if suffix else 1
    while cmds.objExists(f"{base}{num}"):
        num += 1
    return f"{base}{num}"


# ============================================================================
# 链接保护：重命名后扫描场景中按旧名字符串引用灯光的属性（灯光链接等）
# ============================================================================

def _scan_name_references(old_name, new_name):
    """
    扫描场景中所有字符串属性，找出引用了旧灯光名的属性。

    灯光链接、灯光组、表达式等经常按名字引用灯光。
    重命名后这些引用会失效，需要手动更新或告知用户。

    返回: [(节点.属性, 旧值, 新值), ...]
    """
    refs = []
    # 遍历所有节点
    for node in cmds.ls():
        if _is_referenced(node):
            continue
        attrs = cmds.listAttr(node, string=True) or []
        for a in attrs:
            full = node + '.' + a
            try:
                val = cmds.getAttr(full)
            except Exception:
                continue
            if isinstance(val, str) and old_name in val:
                refs.append((full, val, val.replace(old_name, new_name)))
            elif isinstance(val, list):
                # 多值字符串数组
                for idx, v in enumerate(val):
                    if isinstance(v, str) and old_name in v:
                        refs.append((full + '[' + str(idx) + ']', v, v.replace(old_name, new_name)))
    return refs


# ============================================================================
# 核心功能
# ============================================================================

def check_only():
    """
    仅检查场景中的重复灯光命名，不执行任何修改。
    返回重复名称列表。
    """
    all_lights = _get_all_lights()

    # 按短名统计，过滤参考节点
    name_counts = Counter()
    for full_path in all_lights:
        short_name = full_path.split('|')[-1]
        if not _is_referenced(short_name):
            name_counts[short_name] += 1
    duplicates = {name: count for name, count in name_counts.items() if count > 1}

    if not duplicates:
        print("[fix_light_name] ✅ 场景中没有重复命名的灯光。")
        return []

    print("[fix_light_name] ⚠ 发现以下重复命名的灯光：")
    print(f"  {'灯光名':<30} {'出现次数':>8}")
    print(f"  {'-'*30} {'-'*8}")
    for name, count in sorted(duplicates.items()):
        print(f"  {name:<30} {count:>8}")

    print(f"\n[fix_light_name] 共 {len(duplicates)} 个名称重复，涉及 {sum(duplicates.values())} 个灯光。")
    print("[fix_light_name] 运行 fix() 可自动修复。")
    return list(duplicates.keys())


def fix(dry_run=False):
    """
    修复场景中重复命名的灯光。

    对于每组重名灯光：
      - 保留第一个（序号最小或最先出现）
      - 其余重命名为同系列的下一个可用编号

    参数:
        dry_run: True = 仅预览将要执行的重命名（不修改场景）
    """
    all_lights = _get_all_lights()
    # 按短名称分组
    from collections import defaultdict
    name_groups = defaultdict(list)

    for full_path in all_lights:
        short_name = full_path.split('|')[-1]
        # 跳过参考节点
        if _is_referenced(short_name):
            continue
        name_groups[short_name].append(full_path)

    # 筛选出有重复的
    duplicates = {n: paths for n, paths in name_groups.items() if len(paths) > 1}

    if not duplicates:
        print("[fix_light_name] ✅ 场景中没有重复命名的灯光。")
        return 0

    print("[fix_light_name] 开始修复重复灯光命名...")
    print(f"[fix_light_name] 发现 {len(duplicates)} 组重名灯光\n")

    fixed_count = 0

    for short_name, paths in sorted(duplicates.items()):
        print(f"  重名组: '{short_name}' ({len(paths)} 个实例)")

        # 保留第一个，其余重命名
        keep = paths[0]
        to_rename = paths[1:]

        print(f"    保留: {keep}")

        for old_full in to_rename:
            # 生成唯一名称
            new_name = _make_unique_name(short_name)
            old_short = old_full.split('|')[-1]

            if dry_run:
                print(f"    [预览] {old_full} → {new_name}")
                # 预览模式也扫描名字引用
                refs = _scan_name_references(old_short, new_name)
                if refs:
                    print(f"    ⚠ 场景中有 {len(refs)} 处按名字引用该灯光（重命名后需更新）:")
                    for attr, old_val, new_val in refs[:10]:
                        print(f"      - {attr}: '{old_val}' → '{new_val}'")
                continue

            try:
                # 1. 重命名（Maya 自动保留节点连接和集合成员）
                actual = cmds.rename(old_full, new_name)
                print(f"    已重命名: {old_short} → {actual}")

                # 2. 扫描按名字引用旧灯光的字符串属性，自动更新
                refs = _scan_name_references(old_short, new_name)
                if refs:
                    print(f"    🔗 发现 {len(refs)} 处按名字引用，自动更新灯光链接:")
                    for attr, old_val, new_val in refs[:20]:
                        try:
                            cmds.setAttr(attr, new_val, type='string')
                            print(f"      ✓ {attr}")
                        except Exception as e2:
                            print(f"      ✗ {attr} 更新失败: {e2}")
                else:
                    print(f"    🔗 无按名字引用，灯光链接安全")

                fixed_count += 1
            except Exception as e:
                cmds.warning(f"[fix_light_name] 重命名失败: {old_full} → {new_name}, 错误: {e}")

        print()

    if dry_run:
        print(f"[fix_light_name] [预览模式] 将重命名 {fixed_count} 个灯光（未实际修改）")
    else:
        print(f"[fix_light_name] ✅ 修复完成！共重命名 {fixed_count} 个灯光。")

    return fixed_count


# ============================================================================
# 一键运行
# ============================================================================

def run():
    """
    一键检查 + 修复：先展示重复灯光，再执行重命名。
    """
    print("=" * 60)
    print("Maya 灯光重复命名检测与修复工具")
    print("=" * 60)
    print()

    dup_list = check_only()
    if not dup_list:
        return

    print()
    answer = input("[fix_light_name] 是否修复以上重复命名？(y/n): ").strip().lower()
    if answer == 'y':
        fix()
    else:
        print("[fix_light_name] 已取消，未做任何修改。")


# ============================================================================
# 入口
# ============================================================================

if __name__ == "__main__" or __name__ == "__builtin__":
    # 直接运行时：先检查再修复
    dup_list = check_only()
    if dup_list:
        print()
        fix()
