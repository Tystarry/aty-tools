"""
Maya standalone script — fix "Cannot add crypto_asset AOV" error.

What this does:
  1. fix()     — cleans up duplicate AOV aliases in the current scene
  2. patch()   — monkey-patches MtoA's addAliases/createAliases in memory so the
                 same error won't happen again (no admin rights needed)

Usage (in Maya Script Editor, Python tab):
  =========================================

  # One-liner (run this, then open AOV Editor):
  exec(open(r'd:\zcy\ai_ty\fix_aov_crypto_asset.py', encoding='utf-8').read())

  # Or step-by-step:
  import fix_aov_crypto_asset
  fix_aov_crypto_asset.patch()            # prevent future crashes
  fix_aov_crypto_asset.fix("crypto_asset")  # clean up current scene
  =========================================

To make it permanent (auto-run on Maya startup), add these lines to your
Maya userSetup.py or a shelf button.
"""

import maya.cmds as cmds


# ---------------------------------------------------------------------------
# Part 1: Scene cleanup — fix duplicate aliases on shading engines
# ---------------------------------------------------------------------------

def fix(aov_name="crypto_asset"):
    """
    Remove duplicate 'ai_aov_<aov_name>' aliases from all local shading engines.

    Call this BEFORE trying to add the AOV in the AOV Editor.
    """
    alias_name = "ai_aov_" + aov_name
    fixed_count = 0

    shading_engines = cmds.ls(type='shadingEngine')
    if not shading_engines:
        print("[fix_aov] No shading engines found in scene.")
        return

    print("[fix_aov] Scanning {} shading engines for alias '{}'...".format(
        len(shading_engines), alias_name))

    for sg in shading_engines:
        if cmds.referenceQuery(sg, isNodeReferenced=True):
            continue

        existing = cmds.aliasAttr(sg, query=True) or []
        if alias_name not in existing:
            continue

        count = existing.count(alias_name)
        print("[fix_aov]   {}: found '{}' x{} — cleaning...".format(
            sg, alias_name, count))

        try:
            cmds.removeMultiInstance(sg + '.' + alias_name)
        except Exception:
            try:
                cmds.aliasAttr(sg + '.' + alias_name, remove=True)
            except Exception:
                pass

        remaining = cmds.aliasAttr(sg, query=True) or []
        if alias_name not in remaining:
            fixed_count += 1
            print("[fix_aov]     -> cleaned.")
        else:
            print("[fix_aov]     -> WARNING: still present. Try restarting Maya.")

    if fixed_count:
        print("[fix_aov] Done. Fixed {} shading engine(s).".format(fixed_count))
    else:
        print("[fix_aov] No dirty aliases found. You should be able to add "
              "'{}' now.".format(aov_name))


# ---------------------------------------------------------------------------
# Part 2: MtoA runtime patch — prevent the error from happening again
# ---------------------------------------------------------------------------

_patched = False


def _build_safe_add_aliases(original_addAliases):
    """Wrap addAliases so aliasAttr(remove=True) failures fall back to
       removeMultiInstance instead of crashing."""
    def safe_addAliases(aovs):
        for sg in cmds.ls(type='shadingEngine'):
            sgAttr = '{}.aiCustomAOVs'.format(sg)
            # call the original getShadingGroupAOVMap from mtoa.aovs
            from mtoa.aovs import getShadingGroupAOVMap
            nameMapping, nextIndex = getShadingGroupAOVMap(sgAttr)
            for aov in aovs:
                try:
                    plug = nameMapping[aov.name]
                except KeyError:
                    plug = '{}[{}].aovName'.format(sgAttr, nextIndex)
                    cmds.setAttr(plug, aov.name, type="string")
                    nextIndex += 1

                if cmds.referenceQuery(sg, isNodeReferenced=True):
                    continue

                aliasName = 'ai_aov_' + aov.name
                try:
                    cmds.aliasAttr(aliasName, plug)
                except Exception:
                    try:
                        cmds.aliasAttr(sg + '.' + aliasName, remove=True)
                    except Exception:
                        try:
                            cmds.removeMultiInstance(sg + '.' + aliasName)
                        except Exception:
                            pass
                    try:
                        cmds.aliasAttr(aliasName, plug)
                    except Exception:
                        pass
    return safe_addAliases


def _build_safe_create_aliases(original_createAliases):
    """Wrap createAliases with the same removeMultiInstance fallback."""
    def safe_createAliases(sg):
        sg = str(sg)
        if sg == '' or not cmds.objExists(sg):
            return
        if sg == "swatchShadingGroup":
            return

        if cmds.attributeQuery('attributeAliasList', node=sg, exists=True):
            alias_list = '{}.attributeAliasList'.format(sg)
            if cmds.objExists(alias_list) and not cmds.aliasAttr(sg, q=True):
                print("Shading Group %s with bad Attribute Alias list detected. Fixing!" % sg)
                cmds.deleteAttr(alias_list)

        from mtoa.aovs import getAOVNodes, listAvailableIndices
        aovList = getAOVNodes(True)
        sgPlug = "{}.aiCustomAOVs".format(sg)

        sgLogIdx = cmds.getAttr(sgPlug, mi=True) or []
        s = set([cmds.getAttr("{}[{}].aovName".format(sgPlug, i)) for i in sgLogIdx])
        free = listAvailableIndices(sgLogIdx, len(aovList))
        n = 0
        for aov in aovList:
            if aov[0] not in s:
                cmds.setAttr("{}[{}].aovName".format(sgPlug, free[n]), aov[0], typ="string")
                n += 1

        if cmds.referenceQuery(sg, isNodeReferenced=True):
            return

        sgAttr = '{}.aiCustomAOVs'.format(sg)
        attrValues = cmds.getAttr(sgAttr, mi=True) or []
        for i in attrValues:
            at = '{}[{}]'.format(sgAttr, i)
            name = cmds.getAttr('{}.aovName'.format(at))
            aliasName = 'ai_aov_' + name
            try:
                cmds.aliasAttr(aliasName, at)
            except Exception:
                try:
                    cmds.aliasAttr(sg + '.' + aliasName, remove=True)
                except Exception:
                    try:
                        cmds.removeMultiInstance(sg + '.' + aliasName)
                    except Exception:
                        pass
                try:
                    cmds.aliasAttr(aliasName, at)
                except Exception:
                    pass
    return safe_createAliases


def patch():
    """
    Monkey-patch mtoa.aovs.addAliases and mtoa.aovs.createAliases in memory.

    This prevents the "not a unique name" crash when adding AOVs, without
    needing to modify files in Program Files (no admin rights required).

    Call once per Maya session, before opening the AOV Editor.
    Safe to call multiple times.
    """
    global _patched
    if _patched:
        print("[fix_aov] MtoA already patched in this session.")
        return

    try:
        import mtoa.aovs as aovs
        aovs.addAliases = _build_safe_add_aliases(aovs.addAliases)
        aovs.createAliases = _build_safe_create_aliases(aovs.createAliases)
        _patched = True
        print("[fix_aov] MtoA addAliases / createAliases patched in memory. "
              "AOV Editor is now safe to use.")
    except ImportError:
        print("[fix_aov] ERROR: Could not import mtoa.aovs — is Arnold "
              "plugin loaded?")
    except Exception as e:
        print("[fix_aov] ERROR: Failed to patch MtoA: {}".format(e))


# ---------------------------------------------------------------------------
# Quickstart: auto-run when executed
# ---------------------------------------------------------------------------

if __name__ == "__main__" or True:
    patch()
    fix("crypto_asset")
