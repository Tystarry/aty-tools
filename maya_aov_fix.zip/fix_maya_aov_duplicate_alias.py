"""
Maya 脚本 — 修复 "ai_aov_xxx is not a unique name. Cannot remove alias." 错误。

问题原因：着色引擎 (shading engine, 如 initialParticleSE) 上某个 AOV 别名被重复创建，
         MtoA 自带的 removeAliases 无法处理重复别名，导致崩溃。

解决方式：
  1. fix_duplicate_aliases() — 扫描所有着色引擎，用 removeMultiInstance 清理重复别名
  2. patch_mtoa()           — 热修补 MtoA 的 removeAliases，防止日后再次出现同样错误
  3. run()                  — 一键修复 + 打补丁

使用方法（在出问题的 Maya 电脑上操作）：
  方法A — 复制下方一行到 Maya Script Editor (Python 标签页)，回车运行：
    exec(open(r'D:\\zcy\\ai_ty\\fix_maya_aov_duplicate_alias.py', encoding='utf-8').read())

  方法B — 把本文件拷贝到 U 盘，在 Maya Script Editor 中执行：
    exec(open(r'E:\\fix_maya_aov_duplicate_alias.py', encoding='utf-8').read())
    （路径改成 U 盘实际路径）

  方法C — Maya 菜单：File > Script Editor > File > Load Script，加载后 Ctrl+Enter 运行。

  方法D — 命令行启动 Maya 时直接执行（无需打开 UI）：
    mayapy.exe fix_maya_aov_duplicate_alias.py scene.ma

如果需要每次打开 Maya 自动生效，把以下两行加到 userSetup.py：
    import sys; sys.path.append(r'D:\zcy\ai_ty')
    import fix_maya_aov_duplicate_alias; fix_maya_aov_duplicate_alias.patch_mtoa()
"""

import maya.cmds as cmds


# ============================================================================
# 核心修复：清理所有着色引擎上的重复 AOV 别名
# ============================================================================

def fix_duplicate_aliases(target_sg=None):
    """
    扫描着色引擎，移除重复的 AOV 别名。

    参数:
        target_sg: 指定着色引擎名称，如 "initialParticleSE"。
                   为 None 则扫描全部着色引擎。
    返回:
        修复成功的着色引擎数量。
    """
    shading_engines = cmds.ls(type='shadingEngine')
    if not shading_engines:
        print("[fix_aov] 场景中没有着色引擎。")
        return 0

    fixed_count = 0

    for sg in shading_engines:
        # 如果指定了目标着色引擎，只处理它
        if target_sg and sg != target_sg:
            continue

        # 跳过参考节点（referenced nodes）
        if cmds.referenceQuery(sg, isNodeReferenced=True):
            continue

        # 检查该节点上是否有 attributeAliasList
        if not cmds.attributeQuery('attributeAliasList', node=sg, exists=True):
            continue

        all_aliases = cmds.aliasAttr(sg, query=True) or []
        if not all_aliases:
            continue

        # 找出重复的别名（all_aliases 是 [aliasName1, plugName1, aliasName2, plugName2, ...]）
        # 只检查 ai_aov_ 开头的别名
        alias_names = all_aliases[0::2]  # 偶数下标是别名，奇数是插件名
        aov_aliases = [a for a in alias_names if a.startswith('ai_aov_')]

        # 统计各别名出现次数，找出重复项
        from collections import Counter
        dup_aliases = [a for a, cnt in Counter(aov_aliases).items() if cnt > 1]

        if not dup_aliases:
            continue

        print("[fix_aov] {} 发现 {} 个重复 AOV 别名: {}".format(
            sg, len(dup_aliases), ", ".join(dup_aliases)))

        for alias_name in dup_aliases:
            # MtoA 使用 aliasAttr(remove=True) 删除重复别名会报：
            #   "xxx is not a unique name. Cannot remove alias."
            # 解决方法：使用 removeMultiInstance，它能处理重复实例
            attr_full = sg + '.' + alias_name

            try:
                cmds.removeMultiInstance(attr_full, b=True)
                print("[fix_aov]   -> removeMultiInstance 移除 '{}' 成功".format(alias_name))
            except Exception as e1:
                print("[fix_aov]   -> removeMultiInstance 失败: {}".format(e1))
                # 最后的兜底手段：删除并重建 attributeAliasList
                try:
                    alias_list_attr = sg + '.attributeAliasList'
                    cmds.deleteAttr(alias_list_attr)
                    print("[fix_aov]   -> 已删除 {} 整个 attributeAliasList 作为兜底".format(alias_list_attr))
                except Exception as e2:
                    print("[fix_aov]   -> 兜底方案也失败: {}".format(e2))

        # 验证修复结果
        remaining = cmds.aliasAttr(sg, query=True) or []
        remaining_names = remaining[0::2]
        still_dup = [a for a, cnt in Counter(remaining_names).items()
                     if cnt > 1 and a.startswith('ai_aov_')]
        if not still_dup:
            fixed_count += 1
            print("[fix_aov] {} 修复完成，所有重复别名已清理。".format(sg))
        else:
            print("[fix_aov] {} WARNING: 仍有重复别名: {}".format(sg, still_dup))

    print("[fix_aov] 一共修复了 {} 个着色引擎。".format(fixed_count))
    return fixed_count


# ============================================================================
# 热修补：拦截 MtoA 的 removeAliases 函数，让它在内存里就被修正
# ============================================================================

_patched = False


def patch_mtoa():
    """
    热修补 mtoa.aovs.removeAliases 函数。

    把 MtoA 原版的 aliasAttr(remove=True) 替换为：
      1. 先尝试 aliasAttr(remove=True)
      2. 失败则用 removeMultiInstance
      3. 再失败则跳过，不崩溃

    这个补丁只在内存中生效，不需要管理员权限，重启 Maya 后失效。
    如果需要永久生效，请加到 userSetup.py。

    可以安全地多次调用（只生效一次）。
    """
    global _patched
    if _patched:
        print("[fix_aov] MtoA 已经打过补丁，跳过。")
        return

    try:
        import mtoa.aovs as aovs

        original_remove = aovs.removeAliases

        def safe_removeAliases(sg):
            """包裹后的 removeAliases：用 removeMultiInstance 兜底"""
            sg = str(sg)
            if not sg or not cmds.objExists(sg):
                return

            if not cmds.attributeQuery('attributeAliasList', node=sg, exists=True):
                return

            all_aliases = cmds.aliasAttr(sg, query=True) or []
            if not all_aliases:
                return

            for alias in all_aliases:
                if not alias.startswith('ai_aov_'):
                    continue

                full_attr = sg + '.' + alias
                try:
                    cmds.aliasAttr(full_attr, remove=True)
                except RuntimeError as e:
                    # "not a unique name" 错误在这里被拦截
                    print("[fix_aov] aliasAttr remove 失败({}), 改用 removeMultiInstance...".format(alias))
                    try:
                        cmds.removeMultiInstance(full_attr, b=True)
                        print("[fix_aov] removeMultiInstance 成功: {}".format(full_attr))
                    except Exception as e2:
                        print("[fix_aov] removeMultiInstance 也失败({}), 跳过. 错误: {}".format(alias, e2))

        aovs.removeAliases = safe_removeAliases
        _patched = True
        print("[fix_aov] MtoA removeAliases 补丁已生效。")

    except ImportError:
        print("[fix_aov] 无法 import mtoa.aovs，Arnold 插件是否已加载？")
    except Exception as e:
        print("[fix_aov] 打补丁失败: {}".format(e))


# ============================================================================
# 处理特定场景文件（命令行模式）
# ============================================================================

def fix_scene_file(filepath, dry_run=False):
    """
    直接修复 .ma/.mb 文件中的重复别名（文本替换方式）。

    不通过 Maya，直接解析并修改 .ma 文本文件。
    适用于场景打不开、Maya 闪退等无法进入 Maya 的情况。

    参数:
        filepath: .ma 文件的完整路径
        dry_run:  True 则只检查不修改
    """
    import re

    if not filepath.lower().endswith('.ma'):
        print("[fix_aov] 此模式仅支持 .ma (Maya ASCII) 文件。")
        print("[fix_aov] 请将场景另存为 .ma 格式后再试。")
        return

    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()

    # 匹配模式：initialParticleSE 节点中的重复 ai_aov_* 别名
    # .ma 文件中别名以 "attrAliasList" 形式存储在一行或多行
    # 具体格式类似：
    #   setAttr ".attributeAliasList" -type "attributeAlias" ...
    # 或者
    #   addAttr -ci true -sn "ai_aov_xxx" ...

    # 统计匹配到的别名
    alias_pattern = re.compile(r'ai_aov_\w+')
    matches = alias_pattern.findall(content)
    from collections import Counter
    dup_found = {a: c for a, c in Counter(matches).items() if c > 1}

    if not dup_found:
        print("[fix_aov] 场景文件中未发现重复的 AOV 别名。")
        return

    print("[fix_aov] 场景文件中发现以下重复 AOV 别名:")
    for alias, count in dup_found.items():
        print("  {} (出现 {} 次)".format(alias, count))

    if dry_run:
        print("[fix_aov] dry-run 模式，未修改文件。")
        return

    # 修复：对于 .ma 文件，重复别名通常出现在多个 createNode / addAttr 块中
    # 由于 .ma 格式复杂，建议通过 Maya 打开后再用 fix_duplicate_aliases() 修复
    print("[fix_aov] 文件级修复较复杂，建议在 Maya 中打开场景后运行 fix_duplicate_aliases()。")
    print("[fix_aov] 也可以尝试：打开场景 -> 忽略错误 -> Script Editor 中运行 exec(open(...)).")


# ============================================================================
# 一键运行
# ============================================================================

def run(target_sg=None):
    """
    一键修复：先打补丁防止未来出错，再清理当前场景的重复别名。

    参数:
        target_sg: 指定着色引擎名称（如 "initialParticleSE"），None = 全部扫描
    """
    print("=" * 60)
    print("Maya AOV 重复别名修复工具")
    print("=" * 60)

    # 第1步：先打补丁，防止 Mtoa 的 removeAliases 再次崩溃
    patch_mtoa()

    # 第2步：清理当前场景的重复别名
    print("")
    fix_duplicate_aliases(target_sg=target_sg)

    # 第3步：清理后重建 AOV 别名（Mtoa 在下次打开 AOV Editor 时会自动重建）
    print("")
    print("[fix_aov] 完成。现在可以打开 AOV Editor 正常操作了。")


# ============================================================================
# 入口：按 import / 直接 exec() / mayapy 三种方式自动适配
# ============================================================================

if __name__ == "__main__" or __name__ == "__builtin__":
    # 直接运行 / exec() 方式：按需额外指定
    run()
