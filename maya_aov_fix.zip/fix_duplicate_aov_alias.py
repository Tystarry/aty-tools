"""
Maya Python Script - Clean up duplicate AOV alias on initialParticleSE

Usage: paste into Maya Script Editor and run, or:
         exec(open(r'd:\\zcy\\ai_ty\\fix_duplicate_aov_alias.py', encoding='utf-8').read())
"""

import maya.cmds as cmds


def fix_duplicate_alias(sg, alias_name):
    """Remove duplicate alias using removeMultiInstance (same approach as MtoA removeAliases)"""
    all_aliases = cmds.aliasAttr(sg, query=True) or []
    print("Node {} has {} aliases".format(sg, len(all_aliases)))

    if alias_name not in all_aliases:
        print("Alias '{}' not found on {}. Nothing to fix.".format(alias_name, sg))
        return

    try:
        cmds.removeMultiInstance(sg + '.' + alias_name)
        print("Removed alias '{}' via removeMultiInstance.".format(alias_name))
    except Exception as e:
        print("removeMultiInstance failed: {}".format(e))
        try:
            cmds.aliasAttr(sg + '.' + alias_name, remove=True)
            print("Removed alias via aliasAttr remove.")
        except Exception as e2:
            print("aliasAttr remove also failed: {}".format(e2))
            return

    remaining = cmds.aliasAttr(sg, query=True) or []
    if alias_name in remaining:
        print("WARNING: alias '{}' still exists on {}!".format(alias_name, sg))
    else:
        print("Cleanup done. You can now re-add the AOV via AOV Editor.")


if __name__ == "__main__" or True:
    fix_duplicate_alias("initialParticleSE", "ai_aov_crypto_asset")
