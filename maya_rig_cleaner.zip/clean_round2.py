#!/usr/bin/env python3
"""
第二轮清理：移除 8 个验证过的孤儿垃圾节点。
- 4 x groupId（零引用，未绑定任何 sets/shaders）
- 2 x animCurveUU（重复/孤儿动画曲线）
- 1 x polyUnite（遗留构造历史）
- 1 x network（旧版 blendShape 数据容器）
"""

import re
import os

# 确认过的孤儿节点
NODES_TO_REMOVE = {
    "groupId38",
    "groupId66",
    "groupId2044",
    "groupId2222",
    "HeadTopSquetch_zero_squeezeUp_md_input2X1",
    "HeadTopSquetch_zero_squeezeUp_md_input2X2",
    "polyUnite1",
    "blendShape1_data1",
}

def extract_node_name(line):
    m = re.search(r'-n\s+"([^"]+)"', line)
    return m.group(1) if m else None

def process_file(input_path, output_path):
    in_skip = False
    total = 0
    written = 0
    skipped = 0

    with open(input_path, 'r', encoding='utf-8', errors='replace') as fin:
        with open(output_path, 'w', encoding='utf-8', newline='') as fout:
            for line in fin:
                total += 1

                if line.startswith('createNode '):
                    in_skip = False
                    name = extract_node_name(line)
                    if name and name in NODES_TO_REMOVE:
                        in_skip = True
                        skipped += 1
                        continue

                if in_skip:
                    skipped += 1
                    continue

                fout.write(line)
                written += 1

    return total, written, skipped

def main():
    input_file = r"d:\zcy\ai_ty\chr_Viego_rig_pub_v014.ma"
    output_file = input_file + ".clean2"

    size_mb = os.path.getsize(input_file) / (1024 * 1024)
    print(f"输入: {input_file} ({size_mb:.1f} MB)")
    print(f"将要删除 {len(NODES_TO_REMOVE)} 个节点:")
    for n in sorted(NODES_TO_REMOVE):
        print(f"  - {n}")

    total, written, skipped = process_file(input_file, output_file)
    print(f"\n总行数: {total:,}")
    print(f"写入: {written:,}")
    print(f"跳过: {skipped:,}")

    # 替换原文件
    bak = input_file + ".bak2"
    print(f"\n备份: {bak}")
    os.replace(input_file, bak)
    os.replace(output_file, input_file)
    print("完成。")

if __name__ == "__main__":
    main()
