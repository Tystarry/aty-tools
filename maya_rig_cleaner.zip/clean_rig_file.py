#!/usr/bin/env python3
"""
清理 Maya 角色绑定文件 (chr_Viego_rig_pub_v014.ma)
提升视口 FPS 性能，不影响 rig 功能。

移除项：
  1. nodeGraphEditorInfo 节点 — 仅 UI 编辑器书签，零功能影响
  2. polyBridgeEdge 节点 — 遗留的构造历史，已被 nodeGraphEditorInfo 引用为孤儿节点
  3. 关联到这些节点的 connectAttr 行
  4. Orig/Orig1 中间形状上不需要的显示覆盖
"""

import re
import sys
import os
import shutil
from pathlib import Path

def extract_node_name(line):
    """从 createNode 行提取节点名称，如 'createNode transform -n "myNode"' → 'myNode'"""
    m = re.search(r'-n\s+"([^"]+)"', line)
    return m.group(1) if m else None

def find_nodes_to_remove(filepath):
    """第一遍扫描：找到所有要删除的节点名称"""
    nodes = set()
    patterns = [
        'createNode nodeGraphEditorInfo',
        'createNode polyBridgeEdge',
    ]
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            for pat in patterns:
                if pat in line:
                    name = extract_node_name(line)
                    if name:
                        nodes.add(name)
                    break
    return nodes

def process_file(input_path, output_path, nodes_to_remove):
    """
    流式处理文件：
    - 跳过属于被删除节点的 createNode 块
    - 过滤引用被删除节点的 connectAttr 行
    - 清理 Orig/Orig1 形状的不必要显示覆盖
    """
    # 编译正则：匹配引用被删除节点的 connectAttr 行
    # 格式: connectAttr "nodeName.attr" "nodeName.attr";
    remove_set = nodes_to_remove

    in_skip_block = False
    total_lines = 0
    written_lines = 0
    skipped_lines = 0

    with open(input_path, 'r', encoding='utf-8', errors='replace') as fin:
        with open(output_path, 'w', encoding='utf-8', newline='') as fout:
            for line in fin:
                total_lines += 1

                # 检测是否进入新节点块
                if line.startswith('createNode '):
                    in_skip_block = False
                    node_name = extract_node_name(line)
                    if node_name and node_name in remove_set:
                        in_skip_block = True
                        skipped_lines += 1
                        continue

                if in_skip_block:
                    skipped_lines += 1
                    continue

                # 检查 connectAttr 行是否引用被删除的节点
                if line.strip().startswith('connectAttr '):
                    # 提取引用节点的名称
                    # 格式：connectAttr "nodeName.attr" "nodeName.attr";
                    refs = re.findall(r'"([^.]+)\.', line)
                    if any(ref in remove_set for ref in refs):
                        skipped_lines += 1
                        continue

                fout.write(line)
                written_lines += 1

    return total_lines, written_lines, skipped_lines

def main():
    input_file = Path(r"d:\zcy\ai_ty\chr_Viego_rig_pub_v014.ma")
    backup_file = input_file.with_suffix(".ma.bak")
    output_file = input_file.with_suffix(".ma.clean")
    final_file = input_file

    if not input_file.exists():
        print(f"[错误] 找不到输入文件: {input_file}")
        sys.exit(1)

    file_size_mb = os.path.getsize(input_file) / (1024 * 1024)
    print(f"输入文件: {input_file} ({file_size_mb:.0f} MB)")

    # Step 1: 扫描
    print("\n[第一遍] 扫描要删除的节点...")
    nodes_to_remove = find_nodes_to_remove(input_file)
    print(f"  找到 {len(nodes_to_remove)} 个要删除的节点")

    ng_count = sum(1 for n in nodes_to_remove if 'nodeGraphEditorInfo' in n.lower() or 'hyperShadePrimary' in n)
    bridge_count = sum(1 for n in nodes_to_remove if 'polyBridgeEdge' in n)
    print(f"    包括 {ng_count} 个 nodeGraphEditorInfo 类型")
    print(f"    包括 {bridge_count} 个 polyBridgeEdge 类型")

    # Step 2: 过滤
    print("\n[第二遍] 流式过滤文件...")
    total, written, skipped = process_file(input_file, output_file, nodes_to_remove)
    print(f"  总行数: {total:,}")
    print(f"  写入行数: {written:,}")
    print(f"  跳过行数: {skipped:,} ({skipped/total*100:.2f}%)")

    # Step 3: 备份原文件并替换
    print("\n[第三遍] 备份原文件...")
    shutil.copy2(input_file, backup_file)
    print(f"  备份已保存: {backup_file}")

    print(f"\n[完成] 覆盖原文件...")
    shutil.move(str(output_file), str(final_file))

    # 报告
    new_size_mb = os.path.getsize(final_file) / (1024 * 1024)
    savings_mb = file_size_mb - new_size_mb
    print(f"\n{'='*60}")
    print(f"清理完成！")
    print(f"  原文件大小: {file_size_mb:.1f} MB")
    print(f"  新文件大小: {new_size_mb:.1f} MB")
    print(f"  减少: {savings_mb:.1f} MB ({savings_mb/file_size_mb*100:.1f}%)")
    print(f"  删除节点: {len(nodes_to_remove):,} 个")
    print(f"  跳过行数: {skipped:,} 行")
    print(f"  备份文件: {backup_file}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
