#!/usr/bin/env python3
"""
深度扫描 Maya .ma 文件，找出所有可安全清理的垃圾节点。
第二版：检测孤儿节点、纯 UI 节点、冗余历史节点。
"""

import re
import os
import sys
from collections import defaultdict

def scan_all_nodes(filepath):
    """扫描所有节点及其引用关系"""
    nodes = {}  # name -> type
    node_blocks = {}  # name -> list of lines (the createNode block)
    referenced = set()  # nodes referenced in connectAttr
    referencing = defaultdict(set)  # node -> set of nodes it connects to

    create_node_re = re.compile(r'createNode\s+(\S+)\s+-n\s+"([^"]+)"')
    connect_attr_re = re.compile(r'connectAttr\s+"([^.]+)\.([^"]+)"\s+"([^.]+)\.([^"]+)"')

    print("第一遍：扫描所有节点定义...")
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        lines = f.readlines()

    total = len(lines)
    i = 0
    while i < total:
        line = lines[i]
        if line.startswith('createNode '):
            m = create_node_re.search(line)
            if m:
                node_type = m.group(1)
                node_name = m.group(2)
                nodes[node_name] = node_type
        i += 1

    print(f"  找到 {len(nodes):,} 个节点")

    print("第二遍：扫描所有连接关系...")
    for line in lines:
        if line.strip().startswith('connectAttr '):
            m = connect_attr_re.search(line)
            if m:
                src_node = m.group(1)
                dst_node = m.group(3)
                referenced.add(src_node)
                referenced.add(dst_node)
                referencing[src_node].add(dst_node)

    print(f"  找到 {len(referenced):,} 个被引用的节点")

    # 孤儿节点：没有被任何 connectAttr 引用，也不引用其他节点
    orphaned = {}
    for name, ntype in nodes.items():
        if name not in referenced:
            orphaned[name] = ntype

    return nodes, referenced, referencing, orphaned, lines

def is_safe_to_remove(node_name, node_type, nodes, referenced, referencing):
    """判断节点是否可以安全删除"""
    # 排除系统关键节点
    system_prefixes = [':', 'persp', 'top', 'front', 'side', 'default',
                       'layerManager', 'renderLayerManager', 'renderPartition',
                       'lightLinker', 'shapeEditorManager', 'poseInterpolatorManager',
                       'defaultLayer', 'defaultRenderLayer', 'defaultLightSet',
                       'defaultObjectSet', 'initialShadingGroup', 'initialParticleSE',
                       'initialMaterialInfo', 'lambert1', 'particleCloud1',
                       'standardSurface1']

    if node_name.startswith(':'):
        return False, "系统节点"
    for prefix in system_prefixes:
        if node_name == prefix or node_name.startswith(prefix):
            return False, "系统/默认节点"

    # nodeGraphEditorInfo 及其变种 - 已在前一轮删除
    # 检查是否是 UI 相关节点
    ui_patterns = ['hyperShadePrimary', 'hyperGraph', 'hyperLayout',
                   'nodeEditorPanel', 'nodeGraphEditor']

    for pat in ui_patterns:
        if pat in node_name:
            return True, "UI编辑器数据"

    # 基于类型判断
    safe_types = {
        'polyBridgeEdge': '遗留构造历史',
        'polyExtrudeFace': '遗留构造历史',
        'polyExtrudeEdge': '遗留构造历史',
        'polyBevel': '遗留构造历史',
        'polySmoothFace': '遗留构造历史',
        'polySplit': '遗留构造历史',
        'polyTweak': '遗留构造历史',
        'polyDelEdge': '遗留构造历史',
        'polyCloseBorder': '遗留构造历史',
        'polyMergeVert': '遗留构造历史',
    }

    if node_type in safe_types:
        return True, safe_types[node_type]

    # annotationShape - 视口标注，通常不需要
    if node_type == 'annotationShape':
        return True, '视口标注形状'

    return False, f"存在引用或无法确定安全性"

def main():
    filepath = r"d:\zcy\ai_ty\chr_Viego_rig_pub_v014.ma"

    if not os.path.exists(filepath):
        print(f"[错误] 找不到文件: {filepath}")
        sys.exit(1)

    nodes, referenced, referencing, orphaned, lines = scan_all_nodes(filepath)

    # 统计孤儿节点类型
    orphaned_by_type = defaultdict(list)
    for name, ntype in orphaned.items():
        orphaned_by_type[ntype].append(name)

    print(f"\n{'='*60}")
    print(f"孤儿节点分析（未被任何 connectAttr 引用的节点）")
    print(f"{'='*60}")
    print(f"孤儿节点总数: {len(orphaned):,} / {len(nodes):,}")

    # 按类型列出孤儿节点
    print(f"\n孤儿节点类型分布:")
    for ntype, names in sorted(orphaned_by_type.items(), key=lambda x: -len(x[1])):
        safe, reason = is_safe_to_remove(names[0], ntype, nodes, referenced, referencing)
        status = "✓ 可删" if safe else "? 需确认"
        print(f"  {len(names):5d} x {ntype:30s} {status}")

    # 对于特殊可疑类型，检查其连接来源
    print(f"\n{'='*60}")
    print(f"特殊类型深度分析")
    print(f"{'='*60}")

    # 检查 objectSet 是否都是有用的
    if 'objectSet' in orphaned_by_type:
        names = orphaned_by_type['objectSet']
        print(f"\nobjectSet ({len(names)} 个孤儿):")
        for name in names[:10]:
            print(f"  {name}")
        if len(names) > 10:
            print(f"  ... 还有 {len(names) - 10} 个")

    # 检查 groupId 是否都是有用的
    if 'groupId' in orphaned_by_type:
        names = orphaned_by_type['groupId']
        print(f"\ngroupId ({len(names)} 个孤儿):")
        for name in names[:10]:
            print(f"  {name}")
        if len(names) > 10:
            print(f"  ... 还有 {len(names) - 10} 个")

    # 检查 network 节点
    if 'network' in orphaned_by_type:
        names = orphaned_by_type['network']
        print(f"\nnetwork ({len(names)} 个孤儿):")
        for name in names:
            print(f"  {name}")

    # 输出建议
    print(f"\n{'='*60}")
    print(f"删除建议")
    print(f"{'='*60}")

    removable = []
    for ntype, names in orphaned_by_type.items():
        safe, reason = is_safe_to_remove(names[0], ntype, nodes, referenced, referencing)
        if safe:
            print(f"  {len(names):4d} x {ntype:30s} → {reason}")
            removable.extend(names)
        else:
            print(f"  {len(names):4d} x {ntype:30s} → 跳过 ({reason})")

    print(f"\n共 {len(removable)} 个节点建议删除")
    return removable, nodes, lines, orphaned_by_type

if __name__ == "__main__":
    removable, nodes, lines, orphaned_by_type = main()
