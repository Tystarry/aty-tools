#!/usr/bin/env python3
"""
补充清理：移除所有 connectAttr 行中引用已删除的 hyperShadePrimary 节点的内容。
流式处理，避免内存问题。
"""

import re
import os

def clean_hyperShade_refs(filepath):
    """流式移除所有引用 hyperShadePrimary 的 connectAttr 行"""
    tmp = filepath + ".tmp"
    hyper_re = re.compile(r'hyperShadePrimary')

    total = 0
    written = 0
    removed = 0

    with open(filepath, 'r', encoding='utf-8', errors='replace') as fin:
        with open(tmp, 'w', encoding='utf-8', newline='') as fout:
            for line in fin:
                total += 1
                stripped = line.strip()
                if stripped.startswith('connectAttr ') and hyper_re.search(stripped):
                    removed += 1
                else:
                    fout.write(line)
                    written += 1

    os.replace(tmp, filepath)
    return total, written, removed

if __name__ == "__main__":
    filepath = r"d:\zcy\ai_ty\chr_Viego_rig_pub_v014.ma"
    total, written, removed = clean_hyperShade_refs(filepath)
    print(f"总行数: {total:,}")
    print(f"写入: {written:,}")
    print(f"移除: {removed:,}")
