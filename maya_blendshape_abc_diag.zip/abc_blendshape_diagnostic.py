"""Maya 脚本 — ABC 流程 blendShape 诊断 v3（同步自仪表盘模板）"""

import maya.cmds as cmds,json,math
mod="__MOD__";abc="__ABC__"
def sn(n):return n.split("|")[-1].split(":")[-1]
def get_xf(n):
 t=cmds.getAttr(n+".t")[0];r=cmds.getAttr(n+".r")[0];s=cmds.getAttr(n+".s")[0]
 return{"t":[round(v,4)for v in t],"r":[round(v,4)for v in r],"s":[round(v,4)for v in s],"frozen":all(abs(v)<1e-6 for v in t)and all(abs(v)<1e-6 for v in r)and all(abs(v-1)<1e-6 for v in s)}
def build_tree(root):
 # 递归构建层级树, 返回{name,path,is_mesh,is_group,vtx,xf,children:[],children_order:[names]}
 node={"name":sn(root),"path":root,"is_mesh":False,"is_group":True,"vtx":0,"xf":get_xf(root),"children":[],"child_order":[]}
 ch=cmds.listRelatives(root,children=True,type="transform",fullPath=True)or[]
 for c in ch:
  sh=cmds.listRelatives(c,shapes=True,type="mesh",fullPath=True)or[]
  if sh:
   v=cmds.polyEvaluate(c,v=True)
   mnode={"name":sn(c),"path":c,"is_mesh":True,"is_group":False,"vtx":v,"xf":get_xf(c),"children":[],"child_order":[]}
   # 检查中间组节点 transform
   node["children"].append(mnode)
   node["child_order"].append(sn(c))
  else:
   sub=build_tree(c)
   node["children"].append(sub)
   node["child_order"].append(sn(c))
 return node
def walk_tree(node,parent_name,depth,branch_id,result):
 # 深度优先遍历, 按大纲顺序输出扁平列表（组和mesh都输出）
 if not node["is_mesh"] and depth>0:
  result.append({"name":node["name"],"parent":parent_name,"depth":depth,"branch":branch_id,"path":node["path"],"vtx":0,"xf":node["xf"],"is_mesh":False,"is_group":True})
 if node["is_mesh"]:
  result.append({"name":node["name"],"parent":parent_name,"depth":depth,"branch":branch_id,"path":node["path"],"vtx":node["vtx"],"xf":node["xf"],"is_mesh":True})
 else:
  for i,ch in enumerate(node["children"]):
   walk_tree(ch,node["name"],depth+1,branch_id+"_"+str(i),result)
def match_trees(mod_tree,abc_tree,issues):
 # 对比两棵树:组名+顺序+层级
 if mod_tree["name"]!=abc_tree["name"]:issues.append("组名不一致: mod."+mod_tree["name"]+" vs abc."+abc_tree["name"])
 if mod_tree["child_order"]!=abc_tree["child_order"]:issues.append("子级顺序不一致 @"+mod_tree["name"]+": mod"+str(mod_tree["child_order"])+" vs abc"+str(abc_tree["child_order"]))
 for i in range(min(len(mod_tree["children"]),len(abc_tree["children"]))):
  mc=mod_tree["children"][i];ac=abc_tree["children"][i]
  if mc["is_mesh"] and ac["is_mesh"]:continue  # mesh check later
  if mc["is_mesh"]!=ac["is_mesh"]:
   issues.append("类型不一致 @"+mc["name"]+": mod."+("mesh"if mc["is_mesh"]else"group")+" vs abc."+("mesh"if ac["is_mesh"]else"group"))
   continue
  if not mc["is_mesh"]:match_trees(mc,ac,issues)
print("[ABC BS Diagnostic v3]")
mod_root=cmds.ls("__MOD__",long=True)[0];abc_root=cmds.ls("__ABC__",long=True)[0]
mod_tree=build_tree(mod_root);abc_tree=build_tree(abc_root)
issues=[];match_trees(mod_tree,abc_tree,issues)
if issues:
 for iss in issues:print("🏗 "+iss)
else:print("🏗 层级结构一致")
# 收集所有mesh
mr={};mod_list=[];walk_tree(mod_tree,"",0,"M",mod_list)
ar={};abc_list=[];walk_tree(abc_tree,"",0,"A",abc_list)
for m in mod_list:
 if m["is_mesh"]:mr[m["name"]]=m
for m in abc_list:
 if m["is_mesh"]:ar[m["name"]]=m
# 按大纲顺序生成 mod/abc 两个列表
mo=[];ao=[];ok=0;mm=0;nf=0;nh=0;no=0;md={}
for m in mod_list+abc_list:
 n=m["name"]
 if not m["is_mesh"]:continue
 if n in mr and n in ar and n not in md:
  s="ok"if mr[n]["vtx"]==ar[n]["vtx"]else"mismatch"
  if s=="ok":ok+=1
  else:mm+=1
  if not mr[n]["xf"]["frozen"]:nf+=1
  mfull=[sn(p)for p in mr[n]["path"].split("|")];afull=[sn(p)for p in ar[n]["path"].split("|")]
  mrname=sn(mod_root);arname=sn(abc_root)
  mod_parts=mfull[mfull.index(mrname):] if mrname in mfull else mfull
  abc_parts=afull[afull.index(arname):] if arname in afull else afull
  hm=mod_parts==abc_parts
  if not hm:nh+=1
  md[n]={"mod_vtx":mr[n]["vtx"],"abc_vtx":ar[n]["vtx"],"status":s,"mod_transform":mr[n]["xf"],"hierarchy_match":hm,"mod_chain":"|".join(mod_parts),"abc_chain":"|".join(abc_parts)}
 elif n in mr and n not in ar and n not in mo:mo.append(n)
 elif n in ar and n not in mr and n not in ao:ao.append(n)
# 顺序对照：对齐算法 — 单边独有空出，顺序错位标红（含组行和深度信息）
ordered_pairs=[]
mlist_info={m["name"]:m for m in mod_list};alist_info={m["name"]:m for m in abc_list}
mnames=[m["name"] for m in mod_list];anames=[m["name"] for m in abc_list]
i=j=0
while i<len(mnames) or j<len(anames):
 if i<len(mnames) and j<len(anames) and mnames[i]==anames[j]:
  mi=mlist_info[mnames[i]]
  ordered_pairs.append({"mod":mnames[i],"abc":anames[j],"same":True,"is_group":not mi["is_mesh"],"depth":mi["depth"]})
  i+=1;j+=1
 elif i<len(mnames) and j<len(anames) and mnames[i] not in anames and anames[j] not in mnames:
  mi=mlist_info[mnames[i]]
  ordered_pairs.append({"mod":mnames[i],"abc":anames[j],"same":False,"name_mismatch":True,"is_group":not mi["is_mesh"],"depth":mi["depth"]})
  i+=1;j+=1;no+=1
 elif i<len(mnames) and mnames[i] not in anames:
  mi=mlist_info[mnames[i]]
  ordered_pairs.append({"mod":mnames[i],"abc":"","same":False,"mod_only_row":True,"is_group":not mi["is_mesh"],"depth":mi["depth"]})
  i+=1;no+=1
 elif j<len(anames) and anames[j] not in mnames:
  ai=alist_info[anames[j]]
  ordered_pairs.append({"mod":"","abc":anames[j],"same":False,"abc_only_row":True,"is_group":not ai["is_mesh"],"depth":ai["depth"]})
  j+=1;no+=1
 else:
  mi=mlist_info[mnames[i]] if i<len(mnames) else {"is_mesh":True,"depth":0}
  ordered_pairs.append({"mod":mnames[i] if i<len(mnames) else "","abc":anames[j] if j<len(anames) else "","same":False,"is_group":not mi["is_mesh"],"depth":mi["depth"]})
  i+=1;j+=1;no+=1
import datetime as dt
r={"mod_group":mod,"abc_group":abc,"time":dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"summary":{"total_pairs":ok+mm,"ok":ok,"mismatch":mm,"mod_only":len(mo),"abc_only":len(ao),"not_frozen":nf,"hierarchy_mismatch":nh,"order_mismatch":no},"ordered_pairs":ordered_pairs,"mesh_data":md,"mod_only":mo,"abc_only":ao,"structure_issues":issues}

print("\n=== COPY JSON BELOW ===\n"+json.dumps(r,ensure_ascii=False,indent=2))
